import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { explainStudioError, explainThrown } from "./studio-error.ts";
import {
  BOX_APPLY,
  buildLooks,
  carePlan,
  chooseColors,
  curlVerdict,
  fringeVerdict,
  type FaceRead,
  type HairProfile,
} from "./engine.ts";

const MAX_IMAGE = 2_800_000;
const UNAVAILABLE = "Portrait reading is unavailable right now.";

const imageField = z
  .string()
  .min(32)
  .max(MAX_IMAGE)
  .refine((value) => /^data:image\/(jpeg|png|webp);base64,/.test(value), {
    message: "Upload a JPEG, PNG, or WebP photo.",
  });

export type StyleOption = {
  id: string;
  name: string;
  why: string;
  edit: string;
  best: boolean;
  lengthPlan: "keep" | "trim" | "shorter" | "suit";
};

export type ColorOption = {
  id: string;
  name: string;
  hex: string;
  why: string;
  edit: string;
  product: string;
  price: string;
  url: string;
  shop: string;
  best: boolean;
  salonOnly: boolean;
};

export type PortraitReading = {
  faceShape: string;
  undertone: string;
  skinDepth: string;
  contrast: string;
  currentHair: string;
  summary: string;
  lightingOk: boolean;
  lightingNote: string;
  styles: StyleOption[];
  colors: ColorOption[];
  avoid: string[];
  curls: { verdict: "yes" | "maybe" | "no"; reason: string };
  fringe: { verdict: "yes" | "maybe" | "no"; reason: string };
  care: string[];
  doctor: string | null;
  colorNote: string | null;
  apply: string;
};

export type ReadPortraitResult =
  | { ok: true; reading: PortraitReading }
  | { ok: false; message: string };

export type PreviewLookResult = { ok: true; imageUrl: string } | { ok: false; message: string };

export type PhotoCheck = {
  lightingOk: boolean;
  faceSmall: boolean;
  hairTied: boolean;
  glasses: boolean;
  filter: boolean;
  note: string;
};

export type PhotoCheckResult = { ok: true; check: PhotoCheck } | { ok: false; message: string };

const goalId = z.enum(["change", "younger", "eyes", "grey", "grow", "easy"]);
const colourId = z.enum(["black", "dark", "medium", "light", "blonde", "grey", "red"]);
const historyId = z.enum(["never", "box", "salon", "bleach", "balayage", "henna", "relaxer", "keratin", "metal"]);
const problemId = z.enum(["dry", "breakage", "thinning", "slow", "oily", "itchy"]);

const profileSchema = z.object({
  goal: z.array(goalId).min(1).max(6),
  age: z.enum(["under30", "thirties", "forties", "fifties", "sixty"]),
  eyes: z.enum(["brown", "hazel", "green", "blue", "grey"]),
  length: z.enum(["ear", "chin", "shoulder", "long"]),
  cut: z.enum(["no", "trim", "shorter", "suit"]),
  thickness: z.enum(["fine", "medium", "thick"]),
  texture: z.enum(["straight", "wavy", "curly", "coily"]),
  natural: colourId,
  current: colourId,
  grey: z.enum(["none", "some", "half", "most"]),
  pigment: z.enum(["no", "yes", "avoid"]),
  history: z.array(historyId).min(1).max(9),
  ends: z.enum(["dark", "light", "red", "blonde"]).nullable(),
  last: z.enum(["never", "weeks", "months", "year"]),
  problems: z.array(problemId).max(6),
  heat: z.enum(["never", "sometimes", "daily"]),
  time: z.enum(["5", "15", "30"]),
  route: z.enum(["home", "salon"]),
  budget: z.enum(["under150", "mid", "high"]),
  mood: z.enum(["natural", "bold"]),
  curls: z.enum(["yes", "no"]),
  fringe: z.enum(["yes", "no"]),
});

const readInput = z.object({
  imageDataUrl: imageField,
  profile: profileSchema,
});

const previewInput = z.object({
  imageDataUrl: imageField,
  styleName: z.string().trim().min(1).max(80),
  styleEdit: z.string().trim().min(1).max(500),
  colorName: z.string().trim().min(1).max(80),
  colorEdit: z.string().trim().min(1).max(420),
  lengthPlan: z.enum(["keep", "trim", "shorter", "suit"]),
  pigment: z.enum(["no", "yes", "avoid"]),
  grey: z.enum(["none", "some", "half", "most"]),
});

function facePrompt() {
  return `Look at this adult woman's face. This is not a medical reading.
If there is no clear adult face, return {"blocked":true,"reason":"noface"}.
If she appears under 18, return {"blocked":true,"reason":"minor"}.
If the light is too dark, strongly yellow, or one side is in hard shadow, set lightingOk to false. Do not guess skin tone from bad light.
Return only this JSON:
{"blocked":false,"faceShape":"oval|round|square|heart|oblong|diamond|unclear","undertone":"warm|cool|neutral|unknown","skinDepth":"fair|medium|deep|unknown","contrast":"low|medium|high","currentHair":"what you see, one sentence","hairTied":true,"lightingOk":true,"lightingNote":"one short sentence"}
undertone and skinDepth must be "unknown" when lightingOk is false.
No preamble.`;
}

function clip(value: unknown, max: number): string {
  if (typeof value !== "string") return "";
  return value.replace(/\s+/g, " ").trim().slice(0, max);
}

function asRecord(value: unknown): Record<string, unknown> | null {
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  return value as Record<string, unknown>;
}

function errorDetail(json: unknown, status: number): string {
  return explainStudioError(status, json);
}

async function postXai(
  path: string,
  body: unknown,
): Promise<{ ok: true; json: unknown } | { ok: false; status: number; message: string }> {
  const apiKey = process.env.XAI_API_KEY;
  if (!apiKey) return { ok: false, status: 0, message: UNAVAILABLE };

  let response: Response;
  try {
    response = await fetch(`https://api.x.ai/v1${path}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(90_000),
    });
  } catch {
    return { ok: false, status: 0, message: "The studio timed out. Try once more." };
  }

  const text = await response.text();
  let json: unknown = null;
  try {
    json = text ? JSON.parse(text) : null;
  } catch {
    json = null;
  }
  if (!response.ok) {
    return { ok: false, status: response.status, message: errorDetail(json, response.status) };
  }
  return { ok: true, json };
}

function messageText(json: unknown): string {
  const record = asRecord(json);
  const choices = record?.choices;
  if (!Array.isArray(choices) || !choices[0]) return "";
  const message = asRecord(choices[0])?.message;
  const content = asRecord(message)?.content;
  if (typeof content === "string") return content;
  if (!Array.isArray(content)) return "";
  return content
    .map((part) => {
      const row = asRecord(part);
      return typeof row?.text === "string" ? row.text : "";
    })
    .join("");
}

function oneOf<T extends string>(value: unknown, allowed: readonly T[], fallback: T): T {
  const text = clip(value, 24);
  return allowed.includes(text as T) ? (text as T) : fallback;
}

function parseFace(raw: string): { ok: true; face: FaceRead; currentHair: string; contrast: string; lightingNote: string } | { ok: false; message: string } {
  const start = raw.indexOf("{");
  const end = raw.lastIndexOf("}");
  if (start < 0 || end <= start) return { ok: false, message: "The reading came back unreadable. Try again." };
  let parsed: unknown;
  try {
    parsed = JSON.parse(raw.slice(start, end + 1));
  } catch {
    return { ok: false, message: "The reading came back unreadable. Try again." };
  }
  const data = asRecord(parsed);
  if (!data) return { ok: false, message: "The reading came back unreadable. Try again." };
  if (data.blocked === true) {
    const reason = clip(data.reason, 40);
    if (reason === "minor") return { ok: false, message: "Lumen only reads adult portraits. Upload a photo of an adult." };
    return { ok: false, message: "No clear face in that photo. Use a front-facing selfie in even light." };
  }
  const lightingOk = data.lightingOk !== false;
  return {
    ok: true,
    face: {
      faceShape: oneOf(data.faceShape, ["oval", "round", "square", "heart", "oblong", "diamond", "unclear"] as const, "unclear"),
      undertone: lightingOk ? oneOf(data.undertone, ["warm", "cool", "neutral", "unknown"] as const, "unknown") : "unknown",
      skinDepth: lightingOk ? oneOf(data.skinDepth, ["fair", "medium", "deep", "unknown"] as const, "unknown") : "unknown",
      lightingOk,
    },
    currentHair: clip(data.currentHair, 160) || "Not described",
    contrast: oneOf(data.contrast, ["low", "medium", "high"] as const, "medium"),
    lightingNote: clip(data.lightingNote, 180),
  };
}

function readingFrom(profile: HairProfile, face: FaceRead, currentHair: string, contrast: string, lightingNote: string): PortraitReading {
  const chosen = chooseColors(profile, face);
  const looks = buildLooks(profile, face);
  const care = carePlan(profile);
  const colors: ColorOption[] = chosen.colors.map((item, index) => ({
    id: item.dye.id,
    name: item.dye.shade,
    hex: item.dye.hex,
    why: item.why,
    edit: item.dye.edit,
    product: item.dye.product,
    price: item.dye.price,
    url: item.dye.url,
    shop: item.dye.shop,
    best: item.best,
    salonOnly: item.salonOnly,
  }));
  return {
    faceShape: face.faceShape,
    undertone: face.undertone,
    skinDepth: face.skinDepth,
    contrast,
    currentHair,
    summary: face.lightingOk
      ? `${looks[0]?.why ?? "This shape follows your answers."} Colours are chosen from your skin, eyes, and colour history.`
      : lightingNote || "The light is too poor to read your skin tone.",
    lightingOk: face.lightingOk,
    lightingNote: lightingNote || (face.lightingOk ? "Light is good enough to read." : "Retake the photo in daylight."),
    styles: looks.map((item) => ({
      id: item.id,
      name: item.name,
      why: item.why,
      edit: item.edit,
      best: item.best,
      lengthPlan: item.lengthPlan,
    })),
    colors,
    avoid: profile.pigment === "yes" || profile.pigment === "avoid" ? ["Red, auburn, copper, and burgundy"] : [],
    curls: curlVerdict(profile),
    fringe: fringeVerdict(profile, face.faceShape),
    care: care.steps,
    doctor: care.doctor,
    colorNote: chosen.note,
    apply: BOX_APPLY,
  };
}

function imageUrlFrom(json: unknown): string | null {
  const record = asRecord(json);
  const data = record?.data;
  if (Array.isArray(data)) {
    const first = asRecord(data[0]);
    if (typeof first?.url === "string" && first.url.startsWith("http")) return first.url;
    if (typeof first?.b64_json === "string" && first.b64_json.length > 32) {
      return `data:image/jpeg;base64,${first.b64_json}`;
    }
  }
  if (typeof record?.url === "string" && record.url.startsWith("http")) return record.url;
  return null;
}

type JobResult = ReadPortraitResult | PreviewLookResult | PhotoCheckResult;

type Job = { state: "pending" } | { state: "done"; result: JobResult; at: number };

const jobs = new Map<string, Job>();

function keepAlive(work: Promise<unknown>) {
  const safe = work.catch(() => undefined);
  const host = globalThis as { waitUntil?: (promise: Promise<unknown>) => void };
  if (typeof host.waitUntil === "function") host.waitUntil(safe);
}

function finish(id: string, result: JobResult) {
  jobs.set(id, { state: "done", result, at: Date.now() });
  const cutoff = Date.now() - 10 * 60_000;
  for (const [key, job] of jobs) {
    if (job.state === "done" && job.at < cutoff) jobs.delete(key);
  }
}

function enqueue(work: Promise<JobResult>) {
  const id = crypto.randomUUID();
  jobs.set(id, { state: "pending" });
  keepAlive(
    work.then(
      (result) => finish(id, result),
      (error) => finish(id, { ok: false, message: explainThrown(error) }),
    ),
  );
  return { jobId: id };
}

async function runRead(imageDataUrl: string, profile: HairProfile): Promise<ReadPortraitResult> {
  const first = await postXai("/chat/completions", {
    model: "grok-4.5",
    temperature: 0.2,
    max_tokens: 500,
    messages: [
      { role: "system", content: "You read one adult face from a photo. Reply with JSON only. Do not guess skin tone from bad light." },
      {
        role: "user",
        content: [
          { type: "text", text: facePrompt() },
          { type: "image_url", image_url: { url: imageDataUrl } },
        ],
      },
    ],
  });
  if (!first.ok) return { ok: false, message: first.message };
  const text = messageText(first.json);
  if (!text) return { ok: false, message: "The reading came back empty. Try again." };
  const face = parseFace(text);
  if (!face.ok) return face;
  return { ok: true, reading: readingFrom(profile, face.face, face.currentHair, face.contrast, face.lightingNote) };
}

async function runCheck(imageDataUrl: string): Promise<PhotoCheckResult> {
  const first = await postXai("/chat/completions", {
    model: "grok-4.5",
    temperature: 0,
    max_tokens: 300,
    messages: [
      { role: "system", content: "You check one photo for hair advice. Reply with JSON only. Do not invent problems you cannot see." },
      {
        role: "user",
        content: [
          {
            type: "text",
            text: `If there is no clear adult face, return {"blocked":true}.
Otherwise return {"blocked":false,"lightingOk":true,"faceSmall":false,"hairTied":false,"glasses":false,"filter":false,"note":"one short sentence"}.
lightingOk is false only when the light is too dark, yellow, or one-sided to judge skin tone.
faceSmall is true when the face fills less than about a third of the frame.
hairTied is true when the hair is up, clipped, or tied.
glasses is true when she is wearing glasses.
filter is true only when the face is obviously smoothed by a beauty filter. If you are not sure, false.`,
          },
          { type: "image_url", image_url: { url: imageDataUrl } },
        ],
      },
    ],
  });
  if (!first.ok) return { ok: false, message: first.message };
  const text = messageText(first.json);
  const start = text.indexOf("{");
  const end = text.lastIndexOf("}");
  if (start < 0 || end <= start) return { ok: false, message: "The photo check came back unreadable." };
  let parsed: unknown;
  try {
    parsed = JSON.parse(text.slice(start, end + 1));
  } catch {
    return { ok: false, message: "The photo check came back unreadable." };
  }
  const data = asRecord(parsed);
  if (!data) return { ok: false, message: "The photo check came back unreadable." };
  if (data.blocked === true) {
    return { ok: true, check: { lightingOk: false, faceSmall: true, hairTied: false, glasses: false, filter: false, note: "No clear face in that photo." } };
  }
  return {
    ok: true,
    check: {
      lightingOk: data.lightingOk !== false,
      faceSmall: data.faceSmall === true,
      hairTied: data.hairTied === true,
      glasses: data.glasses === true,
      filter: data.filter === true,
      note: clip(data.note, 180) || "Checked.",
    },
  };
}

async function inlineImage(url: string): Promise<string> {
  if (url.startsWith("data:")) return url;
  try {
    const response = await fetch(url, { signal: AbortSignal.timeout(20_000) });
    if (!response.ok) return url;
    const bytes = Buffer.from(await response.arrayBuffer());
    if (bytes.byteLength > 3_500_000) return url;
    const mime = (response.headers.get("content-type") || "image/jpeg").split(";")[0] || "image/jpeg";
    return `data:${mime};base64,${bytes.toString("base64")}`;
  } catch {
    return url;
  }
}

async function runPreview(data: z.infer<typeof previewInput>): Promise<PreviewLookResult> {
  const grey =
    data.grey === "most" || data.grey === "half" || data.grey === "some"
      ? "Cover the grey. Do not leave the ends silver."
      : "";
  const pigment =
    data.pigment === "yes" || data.pigment === "avoid" ? "The colour must not be red, copper, auburn, or burgundy." : "";
  const prompt = [
    "Edit the hair only. The name of the cut and the instruction below are the same cut. Follow both.",
    `Cut name: ${data.styleName}.`,
    data.styleEdit,
    `Hair colour: ${data.colorName}. ${data.colorEdit}. The new colour must be obvious on the hair.`,
    grey,
    pigment,
    "Do not change the face, skin texture, lines, eyes, expression, body, clothing, background, or lighting.",
    "Do not smooth the skin. Do not reshape the face. Do not add people, text, logos, or watermarks.",
    "The hair should meet the scalp naturally.",
  ]
    .filter(Boolean)
    .join(" ");

  const edited = await postXai("/images/edits", {
    model: "grok-imagine-image-2.0",
    prompt,
    image: { type: "image_url", url: data.imageDataUrl },
    response_format: "url",
  });
  if (!edited.ok) return { ok: false, message: edited.message };
  const remote = imageUrlFrom(edited.json);
  if (!remote) return { ok: false, message: "The look was painted, but the image did not come back. Try again." };
  return { ok: true, imageUrl: await inlineImage(remote) };
}

export type StudioJobView = { pending: true } | { pending: false; result: JobResult };

export const readPortrait = createServerFn({ method: "POST" })
  .validator((input: unknown) => readInput.parse(input))
  .handler(async ({ data }) => enqueue(runRead(data.imageDataUrl, data.profile)));

export const checkPortrait = createServerFn({ method: "POST" })
  .validator((input: unknown) => z.object({ imageDataUrl: imageField }).parse(input))
  .handler(async ({ data }) => enqueue(runCheck(data.imageDataUrl)));

export const previewLook = createServerFn({ method: "POST" })
  .validator((input: unknown) => previewInput.parse(input))
  .handler(async ({ data }) => enqueue(runPreview(data)));

export const studioJob = createServerFn({ method: "POST" })
  .validator((input: unknown) => z.object({ jobId: z.string().uuid() }).parse(input))
  .handler(async ({ data }): Promise<StudioJobView> => {
    const job = jobs.get(data.jobId);
    if (!job) return { pending: false, result: { ok: false, message: "That step expired. Try again." } };
    if (job.state === "pending") return { pending: true };
    return { pending: false, result: job.result };
  });

