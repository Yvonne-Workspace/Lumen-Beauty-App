function loadImage(src: string) {
  return new Promise<HTMLImageElement>((resolve, reject) => {
    const image = new Image();
    image.onload = () => resolve(image);
    image.onerror = () => reject(new Error("Could not read that photo."));
    image.src = src;
  });
}

function drawPortrait(source: CanvasImageSource, width: number, height: number, mirror = false) {
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const context = canvas.getContext("2d");
  if (!context) throw new Error("Could not prepare that photo.");
  if (mirror) {
    context.translate(width, 0);
    context.scale(-1, 1);
  }
  context.drawImage(source, 0, 0, width, height);
  return canvas.toDataURL("image/jpeg", 0.85);
}

function fittedSize(width: number, height: number) {
  const scale = Math.min(1, 1280 / Math.max(width, height));
  return {
    width: Math.max(1, Math.round(width * scale)),
    height: Math.max(1, Math.round(height * scale)),
  };
}

export async function fileToPortrait(file: File): Promise<string> {
  const objectUrl = URL.createObjectURL(file);
  try {
    const image = await loadImage(objectUrl);
    const size = fittedSize(image.width, image.height);
    return drawPortrait(image, size.width, size.height);
  } catch {
    throw new Error("This photo format isn't supported. Use a JPEG or PNG.");
  } finally {
    URL.revokeObjectURL(objectUrl);
  }
}

export function frameToPortrait(video: HTMLVideoElement, mirror: boolean) {
  if (video.videoWidth < 2 || video.videoHeight < 2) {
    throw new Error("The camera is not ready yet.");
  }
  const size = fittedSize(video.videoWidth, video.videoHeight);
  return drawPortrait(video, size.width, size.height, mirror);
}

export async function fitPortrait(dataUrl: string): Promise<string> {
  const image = await loadImage(dataUrl);
  const long = Math.max(image.width, image.height);
  if (long <= 1280 && dataUrl.startsWith("data:image/jpeg") && dataUrl.length < 1_600_000) return dataUrl;
  const size = fittedSize(image.width, image.height);
  return drawPortrait(image, size.width, size.height);
}
