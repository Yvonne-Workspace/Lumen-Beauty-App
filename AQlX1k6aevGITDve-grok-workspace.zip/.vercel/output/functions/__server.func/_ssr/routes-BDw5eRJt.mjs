import { i as __toESM } from "../_runtime.mjs";
import { b as require_jsx_runtime, q as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as string, r as object } from "../_libs/zod.mjs";
import { i as ImagePlus, n as ScanFace, r as LoaderCircle } from "../_libs/lucide-react.mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BDw5eRJt.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var imageField = string().min(32).max(28e5).refine((value) => /^data:image\/(jpeg|png|webp);base64,/.test(value), { message: "Upload a JPEG, PNG, or WebP photo." });
var readInput = object({ imageDataUrl: imageField });
var previewInput = object({
	imageDataUrl: imageField,
	styleName: string().trim().min(1).max(80),
	styleEdit: string().trim().min(1).max(420),
	colorName: string().trim().min(1).max(80),
	colorEdit: string().trim().min(1).max(420)
});
var readPortrait = createServerFn({ method: "POST" }).validator((input) => readInput.parse(input)).handler(createSsrRpc("829bbd9341bd491bc3a60e48d93cf505a7c3266b4954c5300573250b5787e634"));
var previewLook = createServerFn({ method: "POST" }).validator((input) => previewInput.parse(input)).handler(createSsrRpc("54b934eda3802a46675c22de7962aa31156f09761a399ae68d4d5ac6be7140fc"));
var studioJob = createServerFn({ method: "POST" }).validator((input) => object({ jobId: string().uuid() }).parse(input)).handler(createSsrRpc("d400fa8c6d1760fa1efc24afa18ec356cf6284a2ed48e1e1a89e5c4bf547ebb9"));
var SAMPLE_SRC = "/portraits/sample.jpg";
function lookKey(styleId, colorId) {
	return `${styleId}:${colorId}`;
}
function loadImage(src) {
	return new Promise((resolve, reject) => {
		const image = new Image();
		image.onload = () => resolve(image);
		image.onerror = () => reject(/* @__PURE__ */ new Error("Could not read that photo."));
		image.src = src;
	});
}
async function fileToPortrait(file) {
	const objectUrl = URL.createObjectURL(file);
	try {
		const image = await loadImage(objectUrl);
		const scale = Math.min(1, 896 / Math.max(image.width, image.height));
		const width = Math.max(1, Math.round(image.width * scale));
		const height = Math.max(1, Math.round(image.height * scale));
		const canvas = document.createElement("canvas");
		canvas.width = width;
		canvas.height = height;
		const context = canvas.getContext("2d");
		if (!context) throw new Error("Could not prepare that photo.");
		context.drawImage(image, 0, 0, width, height);
		return canvas.toDataURL("image/jpeg", .82);
	} catch {
		throw new Error("This photo format isn't supported. Use a JPEG or PNG.");
	} finally {
		URL.revokeObjectURL(objectUrl);
	}
}
async function waitForJob(jobId) {
	for (let attempt = 0; attempt < 45; attempt += 1) {
		const step = await studioJob({ data: { jobId } });
		if (!step.pending) return step.result;
		await new Promise((resolve) => setTimeout(resolve, 2e3));
	}
	return {
		ok: false,
		message: "That is still running. Stay on this page and try once more."
	};
}
function PortraitFrame({ original, painted, split, onSplit, busy, busyLabel }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "frame",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: painted ?? original,
				alt: painted ? "Portrait with the chosen haircut and color" : "Uploaded portrait",
				className: "block aspect-[3/4] w-full object-cover"
			}),
			painted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: original,
				alt: "",
				className: "pointer-events-none absolute inset-0 aspect-[3/4] h-full w-full object-cover",
				style: { clipPath: `inset(0 ${100 - split}% 0 0)` }
			}) : null,
			painted ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "pointer-events-none absolute inset-y-0 w-px bg-sheet",
					style: { left: `${split}%` }
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "pointer-events-none absolute top-1/2 grid size-9 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full border border-line bg-sheet text-xs font-medium text-ink",
					style: { left: `${split}%` },
					children: "||"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "sr-only",
					htmlFor: "compare",
					children: "Compare original and painted look"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					id: "compare",
					className: "compare-range",
					type: "range",
					min: 2,
					max: 98,
					value: split,
					onChange: (event) => onSplit(Number(event.target.value))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "pointer-events-none absolute inset-x-0 bottom-0 flex justify-between px-3 py-2 text-xs font-medium text-char-fg",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "rounded-full bg-char/80 px-2 py-1",
						children: "Original"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "rounded-full bg-char/80 px-2 py-1",
						children: "Painted"
					})]
				})
			] }) : null,
			busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-0 grid place-items-center bg-ink/35 text-sm font-medium text-char-fg",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "inline-flex items-center gap-2 rounded-full bg-char px-3 py-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
						className: "size-4 animate-spin",
						"aria-hidden": "true"
					}), busyLabel]
				})
			}) : null
		]
	});
}
function LumenStudio() {
	const inputRef = (0, import_react.useRef)(null);
	const busyRef = (0, import_react.useRef)(false);
	const [portrait, setPortrait] = (0, import_react.useState)(null);
	const [hot, setHot] = (0, import_react.useState)(false);
	const [reading, setReading] = (0, import_react.useState)(null);
	const [styleId, setStyleId] = (0, import_react.useState)(null);
	const [colorId, setColorId] = (0, import_react.useState)(null);
	const [previews, setPreviews] = (0, import_react.useState)({});
	const [split, setSplit] = (0, import_react.useState)(56);
	const [phase, setPhase] = (0, import_react.useState)("idle");
	const [notice, setNotice] = (0, import_react.useState)(null);
	const style = reading?.styles.find((item) => item.id === styleId) ?? null;
	const color = reading?.colors.find((item) => item.id === colorId) ?? null;
	const painted = style && color ? previews[lookKey(style.id, color.id)] ?? null : null;
	const facts = (0, import_react.useMemo)(() => {
		if (!reading) return [];
		return [
			["Face", reading.faceShape],
			["Undertone", reading.undertone],
			["Contrast", reading.contrast]
		];
	}, [reading]);
	async function useFile(file) {
		if (!file) return;
		setNotice(null);
		try {
			const next = await fileToPortrait(file);
			setPortrait(next);
			setReading(null);
			setStyleId(null);
			setColorId(null);
			setPreviews({});
			setSplit(56);
		} catch (error) {
			setNotice(error instanceof Error ? error.message : "Could not use that photo.");
		}
	}
	async function useSample() {
		setNotice(null);
		setPhase("reading");
		try {
			const response = await fetch(SAMPLE_SRC);
			if (!response.ok) throw new Error("The sample portrait is missing.");
			const blob = await response.blob();
			const next = await fileToPortrait(new File([blob], "sample.jpg", { type: blob.type || "image/jpeg" }));
			setPortrait(next);
			setReading(null);
			setStyleId(null);
			setColorId(null);
			setPreviews({});
			setPhase("idle");
		} catch (error) {
			setPhase("idle");
			setNotice(error instanceof Error ? error.message : "Could not load the sample.");
		}
	}
	async function onRead() {
		if (!portrait || phase !== "idle" || busyRef.current) return;
		busyRef.current = true;
		setPhase("reading");
		setNotice(null);
		try {
			const result = await waitForJob((await readPortrait({ data: { imageDataUrl: portrait } })).jobId);
			if (!result.ok || !("reading" in result)) {
				setReading(null);
				setNotice("message" in result ? result.message : "The reading did not go through. Try again.");
				return;
			}
			setReading(result.reading);
			setStyleId(result.reading.styles[0]?.id ?? null);
			setColorId(result.reading.colors[0]?.id ?? null);
		} catch {
			setNotice("The reading did not go through. Try again.");
		} finally {
			busyRef.current = false;
			setPhase("idle");
		}
	}
	async function onPaint() {
		if (!portrait || !style || !color || phase !== "idle" || busyRef.current) return;
		const key = lookKey(style.id, color.id);
		if (previews[key]) return;
		busyRef.current = true;
		setPhase("painting");
		setNotice(null);
		try {
			const result = await waitForJob((await previewLook({ data: {
				imageDataUrl: portrait,
				styleName: style.name,
				styleEdit: style.edit,
				colorName: color.name,
				colorEdit: color.edit
			} })).jobId);
			if (!result.ok || !("imageUrl" in result)) {
				setNotice("message" in result ? result.message : "That look did not paint. Try again.");
				return;
			}
			setPreviews((current) => ({
				...current,
				[key]: result.imageUrl
			}));
			setSplit(56);
		} catch {
			setNotice("That look did not paint. Try again.");
		} finally {
			busyRef.current = false;
			setPhase("idle");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "studio-shell",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "mb-8 flex items-end justify-between gap-4 md:mb-10",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium tracking-widest text-stone uppercase",
				children: "Studio"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "wordmark mt-1 text-4xl text-ink md:text-5xl",
				children: "Lumen"
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "hidden max-w-xs text-right text-sm text-stone md:block",
				children: "A cut and a color chosen for the face in the photo, then painted back onto it."
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid items-start gap-6 lg:grid-cols-[minmax(0,0.92fr)_minmax(0,1.08fr)] lg:gap-8",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "panel p-4",
				children: [
					portrait ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PortraitFrame, {
						original: portrait,
						painted,
						split,
						onSplit: setSplit,
						busy: phase !== "idle",
						busyLabel: phase === "reading" ? "Reading the face" : "Painting the hair"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: hot ? "drop is-hot" : "drop",
						onDragOver: (event) => {
							event.preventDefault();
							setHot(true);
						},
						onDragLeave: () => setHot(false),
						onDrop: (event) => {
							event.preventDefault();
							setHot(false);
							useFile(event.dataTransfer.files[0]);
						},
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, {
								className: "size-6 text-stone",
								"aria-hidden": "true"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-medium text-ink",
								children: "Drop a front-facing selfie"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 max-w-xs text-sm text-stone",
								children: "Even light, hair visible, just you in the frame. Photos stay in this session."
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 flex flex-wrap justify-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "btn btn-primary",
									onClick: () => inputRef.current?.click(),
									children: "Upload a photo"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "btn btn-quiet",
									onClick: () => void useSample(),
									disabled: phase !== "idle",
									children: "Use the sample"
								})]
							})
						]
					}),
					portrait ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex flex-wrap gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn btn-quiet",
							onClick: () => inputRef.current?.click(),
							children: "Replace photo"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn btn-primary",
							onClick: () => void onRead(),
							disabled: phase !== "idle",
							children: phase === "reading" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
								className: "size-4 animate-spin",
								"aria-hidden": "true"
							}), "Reading"] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScanFace, {
								className: "size-4",
								"aria-hidden": "true"
							}), "Read this portrait"] })
						})]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						ref: inputRef,
						className: "sr-only",
						type: "file",
						accept: "image/*",
						onChange: (event) => {
							useFile(event.target.files?.[0]);
							event.target.value = "";
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 px-1 text-xs text-mist",
						children: "Used only to read the face and paint the hair. Not saved in Lumen."
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex flex-col gap-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "wordmark text-3xl text-ink",
						children: "What suits this face"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 max-w-prose text-sm text-stone md:text-base",
						children: reading ? reading.summary : "Upload a selfie, then read it. Lumen returns four cuts and four colors, and paints the pair you choose onto the same photo."
					})] }),
					notice ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "note",
						children: notice
					}) : null,
					reading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
							className: "grid grid-cols-3 gap-2",
							children: facts.map(([label, value]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-md border border-line bg-sheet px-3 py-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-xs text-mist",
									children: label
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "mt-0.5 text-sm font-medium capitalize text-ink",
									children: value
								})]
							}, label))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-stone",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-medium text-ink",
								children: "Now: "
							}), reading.currentHair]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-sm font-medium text-ink",
							children: "Cuts"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 grid gap-2",
							children: reading.styles.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StyleRow, {
								item,
								pressed: item.id === styleId,
								onPick: () => setStyleId(item.id)
							}, item.id))
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-sm font-medium text-ink",
							children: "Colors"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 grid gap-2 sm:grid-cols-2",
							children: reading.colors.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ColorRow, {
								item,
								pressed: item.id === colorId,
								onPick: () => setColorId(item.id)
							}, item.id))
						})] }),
						reading.avoid.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-stone",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-medium text-ink",
								children: "Leave alone: "
							}), reading.avoid.join(" · ")]
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "btn btn-primary",
								disabled: !style || !color || phase !== "idle" || Boolean(painted),
								onClick: () => void onPaint(),
								children: painted ? "Painted on the photo" : phase === "painting" ? "Painting" : "Paint this look"
							}), painted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								className: "text-sm font-medium text-ink underline decoration-line underline-offset-4",
								href: painted,
								target: "_blank",
								rel: "noreferrer",
								children: "Open full size"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-mist",
								children: "One look at a time. Switching back does not paint it again."
							})]
						})
					] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
						className: "grid gap-3 text-sm text-stone",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "panel px-4 py-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium text-ink",
									children: "1. Portrait. "
								}), "A clear selfie, or the sample if you want to see the studio first."]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "panel px-4 py-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium text-ink",
									children: "2. Reading. "
								}), "Face shape, undertone, and contrast decide the cuts and colors."]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "panel px-4 py-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium text-ink",
									children: "3. Paint. "
								}), "The chosen pair is edited onto your photo. Drag the divider to compare."]
							})
						]
					})
				]
			})]
		})]
	});
}
function StyleRow({ item, pressed, onPick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		className: "choice",
		"aria-pressed": pressed,
		onClick: onPick,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "block text-sm font-medium text-ink",
			children: item.name
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mt-1 block text-sm text-stone",
			children: item.why
		})]
	});
}
function ColorRow({ item, pressed, onPick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		className: "swatch",
		"aria-pressed": pressed,
		onClick: onPick,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "size-8 shrink-0 rounded-sm border border-line",
			style: { background: item.hex },
			"aria-hidden": "true"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "block text-sm font-medium text-ink",
			children: item.name
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mt-0.5 block text-xs text-stone",
			children: item.why
		})] })]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LumenStudio, {});
}
//#endregion
export { Home as component };
