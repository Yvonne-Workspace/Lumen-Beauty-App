import { createFileRoute } from "@tanstack/react-router";
import { LumenStudio } from "@/components/lumen-studio";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <LumenStudio />;
}
