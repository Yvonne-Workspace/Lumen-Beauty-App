import assert from "node:assert/strict";
import test from "node:test";
import { DYE_DATABASE } from "./dye-database.ts";
import { matchHome } from "./dye-match.ts";
import type { HairProfile } from "./engine.ts";

function profile(over: Partial<HairProfile> = {}): HairProfile {
  return {
    goal: ["change"],
    age: "thirties",
    eyes: "brown",
    length: "shoulder",
    cut: "no",
    thickness: "medium",
    texture: "straight",
    natural: "dark",
    current: "dark",
    grey: "none",
    pigment: "no",
    history: ["never"],
    ends: null,
    last: "never",
    problems: [],
    heat: "sometimes",
    time: "15",
    route: "home",
    budget: "mid",
    mood: "natural",
    curls: "no",
    fringe: "no",
    ...over,
  };
}

test("box dyes come only from the database", () => {
  const ids = new Set(DYE_DATABASE.map((item) => item.id));
  const match = matchHome(profile(), "colorsilk-30");
  assert.ok(match.cards.length > 0);
  for (const card of match.cards) {
    assert.ok(ids.has(card.dye.id));
    assert.equal(card.dye.showInApp, true);
    assert.notEqual(card.dye.tier, "Budget");
  }
  assert.equal(match.cards.some((card) => card.role === "Best match"), true);
});

test("no red drops yes and maybe, and red pigment drops warm", () => {
  const auburn = matchHome(profile({ pigment: "avoid" }), "colorsilk-31");
  for (const card of auburn.cards) {
    assert.equal(card.dye.containsRed, "No");
    assert.notEqual(card.dye.tone, "Red / violet");
  }
  const warm = matchHome(profile({ pigment: "yes", current: "medium", natural: "medium" }), "nice-easy-5g");
  assert.equal(warm.cards.length, 0);
});

test("dyed dark hair cannot be lifted with a box", () => {
  const match = matchHome(profile({ history: ["box"], current: "dark", natural: "dark", last: "months" }), "clicks-pref-91");
  assert.match(match.salonOnly ?? "", /already dyed|lighter/i);
  for (const card of match.cards) assert.ok((card.dye.level ?? 99) <= 4);
});

test("henna, keratin, and metal colour block box dye", () => {
  assert.match(matchHome(profile({ history: ["henna"] }), "colorsilk-30").blocked ?? "", /strand test/i);
  assert.match(matchHome(profile({ history: ["keratin"] }), "colorsilk-30").blocked ?? "", /strand test/i);
  assert.match(matchHome(profile({ history: ["metal"] }), "colorsilk-30").blocked ?? "", /strand test/i);
  assert.match(
    matchHome(profile({ history: ["relaxer"], last: "weeks" }), "colorsilk-30").blocked ?? "",
    /salon/i,
  );
});

test("heavy grey avoids ash and dyes that do not claim coverage", () => {
  const match = matchHome(profile({ grey: "half", natural: "medium", current: "medium" }), "colorstay-512");
  assert.equal(match.cards.length, 0);
  const neutral = matchHome(profile({ grey: "most", natural: "medium", current: "medium" }), "clicks-excellence-5u");
  for (const card of neutral.cards) {
    assert.equal(card.dye.tone === "Ash / cool", false);
    assert.equal(card.dye.greyClaim.startsWith("Yes"), true);
  }
});

test("damaged hair puts the gentler dye first when one is in range", () => {
  const match = matchHome(profile({ problems: ["breakage"], current: "dark", natural: "dark" }), "clicks-nutrisse-30");
  assert.equal(match.cards[0]?.role, "Gentler option");
  assert.equal(match.cards[0]?.dye.type, "Semi-permanent");
});
