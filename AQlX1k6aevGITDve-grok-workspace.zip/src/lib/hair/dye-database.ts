export type DyeTone = "Ash / cool" | "Neutral" | "Golden / warm" | "Red / violet";
export type ContainsRed = "Yes" | "No" | "Maybe";

export type BoxDye = {
  id: string;
  brand: string;
  range: string;
  shadeName: string;
  shadeNo: string;
  level: number | null;
  tone: DyeTone;
  containsRed: ContainsRed;
  type: "Permanent" | "Semi-permanent";
  tier: "Quality" | "Quality - gentler" | "Budget";
  store: "Clicks";
  price: number | null;
  priceStatus: string;
  lastChecked: string;
  url: string;
  notes: string;
  greyClaim: string;
  showInApp: boolean;
};

/** Version 2, 16 Nov 2026. Shown dyes are Show in app = Yes and not Budget. */
const ROWS: BoxDye[] = [
  row("D001", "L'Oréal Paris", "Excellence Crème", "Natural Darkest Brown", "3", 3, "Neutral", "No", "Permanent", "Quality", null, "Price not seen - check", "https://clicks.co.za/loreal_excellence-creme-hair-colour-natural-darkest-brown-3/p/0000U98D", "Brand page states 100% grey coverage.", "Yes - Clicks page claims up to 100%", true),
  row("D002", "L'Oréal Paris", "Excellence Crème", "Darkest Brown", "2U", 2, "Neutral", "No", "Permanent", "Quality", 220, "Price seen in Clicks listing - confirm", "https://www.clicks.co.za/beauty/hair/hair-colour/natural/c/OH400156", "Link opens the Clicks category page, not the product. Search the shade name there.", "Not confirmed", true),
  row("D003", "L'Oréal Paris", "Excellence Crème", "Natural Brown", "5", 5, "Neutral", "No", "Permanent", "Quality", 220, "Price seen in Clicks listing - confirm", "https://clicks.co.za/loreal_excellence-creme-hair-colour-natural-brown-5/p/910653", "Brand page: 100% grey coverage, 30 min development.", "Yes - Clicks page claims up to 100%", true),
  row("D004", "L'Oréal Paris", "Excellence Crème", "Natural Iced Brown", "(confirm on pack)", 5, "Ash / cool", "No", "Permanent", "Quality", 220, "Price seen in Clicks listing - confirm", "https://clicks.co.za/loreal_creme-hair-colour-excellence-natural-iced-brown/p/00004U58", "Level inferred from the UK shade Iced Brown 5.15. Confirm shade number on the SA pack.", "Not confirmed", true),
  row("D005", "L'Oréal Paris", "Excellence Crème", "Natural Mahogany Brown", "(confirm on pack)", 5, "Red / violet", "Yes", "Permanent", "Quality", null, "Price not seen - check", "https://clicks.co.za/p/910687", "Red/violet shade. Exclude when the client says no red.", "Not confirmed", true),
  row("D006", "L'Oréal Paris", "Excellence Crème", "Natural Light Blonde", "9", 9, "Neutral", "No", "Permanent", "Quality", 220, "Price seen in Clicks listing - confirm", "https://clicks.co.za/beauty/hair/hair-colour/permanent/c/OH400111", "Needs a light starting colour. Not for dark or dyed-dark hair at home. Link opens the Clicks category page, not the product. Search the shade name there.", "Not confirmed", true),
  row("D007", "L'Oréal Paris", "Preference Superior", "Golden Brown", "(confirm on pack)", null, "Golden / warm", "No", "Permanent", "Quality", 264, "Price seen in Clicks listing - confirm", "https://www.clicks.co.za/beauty/hair/hair-colour/natural/c/OH400156", "Level not seen - confirm on pack. Warm tones can pull orange on some hair. Link opens the Clicks category page, not the product. Search the shade name there.", "Not confirmed", true),
  row("D008", "L'Oréal Paris", "Preference Superior", "Light Ash Blond", "9.1", 9, "Ash / cool", "No", "Permanent", "Quality", 265, "Price seen in Clicks listing - confirm", "https://clicks.co.za/beauty/hair/hair-colour/permanent/c/OH400111", "Needs a light starting colour. Not for dark or dyed-dark hair at home. Link opens the Clicks category page, not the product. Search the shade name there.", "Not confirmed", true),
  row("D009", "L'Oréal Paris", "Preference", "Ultra-Light Cool Pearl Blonde", "11.21", 10, "Ash / cool", "No", "Permanent", "Quality", 264, "Price seen in Clicks listing - confirm", "https://www.clicks.co.za/beauty/hair/hair-colour/natural/c/OH400156", "Very light shade (level 11 on pack, shown as 10 here). Realistically salon territory for most women. Link opens the Clicks category page, not the product. Search the shade name there.", "Not confirmed", true),
  row("D010", "L'Oréal Paris", "Casting Crème Gloss", "Darkest Brown", "300", 3, "Neutral", "No", "Semi-permanent", "Quality - gentler", 200, "Price seen in Clicks listing - confirm", "https://clicks.co.za/beauty/hair/hair-colour/permanent/c/OH400111", "Semi-permanent conditioning colour. Good for refreshing shine and colour. Does not lift hair and is not for full grey coverage. Link opens the Clicks category page, not the product. Search the shade name there.", "Not confirmed", true),
  row("D011", "Garnier", "Nutrisse Crème", "Darkest Brown", "3.0", 3, "Neutral", "No", "Permanent", "Quality", 155, "Price seen in Clicks listing - confirm", "https://clicks.co.za/beauty/hair/hair-colour/permanent/no-ammonia/c/OH400111", "Listed in the Clicks no-ammonia category - confirm on pack. Link opens the Clicks category page, not the product. Search the shade name there.", "Not confirmed", true),
  row("D012", "Garnier", "Nutrisse Crème", "Crimson Promise", "3.6", 3, "Red / violet", "Yes", "Permanent", "Quality", 155, "Price seen in Clicks listing - confirm", "https://clicks.co.za/beauty/hair/hair-colour/permanent/c/OH400111", "Red/violet shade. Exclude when the client says no red. Link opens the Clicks category page, not the product. Search the shade name there.", "Not confirmed", true),
  row("D013", "Garnier", "Nutrisse Crème", "Dark Brown / Cocoa", "4.0", 4, "Neutral", "No", "Permanent", "Quality", null, "Price not seen - check", "https://clicks.co.za/garnier_nutrisse-creme-permanent-nourishing-hair-colour-brown-4/p/98253", "Same shade also listed at https://www.clicks.co.za/garnier_nutrisse-creme-deeply-nourishing-permanent-hair-colour-cocoa-4-0/p/00035YD5", "Yes - Clicks page claims up to 100%", true),
  row("D014", "Garnier", "Nutrisse Crème", "Pure Chocolate (4 1/2 Medium Dark Brown)", "4.12", 4, "Ash / cool", "No", "Permanent", "Quality", null, "Price not seen - check", "https://clicks.co.za/garnier_nutrisse-creme-deeply-nourishing-permanent-hair-colour-pure-chocolate-4-12/p/00035YD7", "Tone inferred from the shade number - confirm on pack.", "Yes - Clicks page claims up to 100%", true),
  row("D015", "Garnier", "Nutrisse Crème", "Iced Coffee", "4.15", 4, "Ash / cool", "Maybe", "Permanent", "Quality", 155, "Price seen in Clicks listing - confirm", "https://clicks.co.za/beauty/hair/hair-colour/permanent/no-ammonia/c/OH400111", "Cool brown that may carry a faint mahogany hint. Treat as maybe red until confirmed on pack. Link opens the Clicks category page, not the product. Search the shade name there.", "Not confirmed", true),
  row("D016", "Garnier", "Nutrisse Crème", "Frozen Brown", "(confirm on pack)", null, "Ash / cool", "No", "Permanent", "Quality", null, "Price not seen - check", "https://clicks.co.za/garnier_nutrisse-hair-dye-frozen-brown-cream/p/0001FKC2", "Level and tone inferred from the name only. Confirm on pack.", "Yes - Clicks page claims up to 100%", true),
  row("D017", "Garnier", "Nutrisse Crème", "Mocha Brown", "5", 5, "Neutral", "No", "Permanent", "Quality", null, "Price not seen - check", "https://www.clicks.co.za/garnier_nutrisse-creme-hair-colour-5-brown-1-application/p/98248", "Brand page: up to 100% grey coverage.", "Yes - Clicks page claims up to 100%", true),
  row("D018", "Garnier", "Nutrisse Crème", "Light Brown", "6", 6, "Neutral", "No", "Permanent", "Quality", null, "Price not seen - check", "https://clicks.co.za/garnier_nutrisse-creme-deeply-nourishing-permanent-hair-colour-light-brown-6/p/00035YDB", "Brand page: choose the lighter shade if between two. Result depends on current colour.", "Yes - Clicks page claims up to 100%", true),
  row("D019", "Garnier", "Nutrisse Crème", "Dark Blonde", "7", 7, "Neutral", "No", "Permanent", "Quality", 155, "Price seen in Clicks listing - confirm", "https://clicks.co.za/beauty/hair/hair-colour/permanent/no-ammonia/c/OH400111", "Multi-tonal blonde. Do not use on very light or bleached hair without a salon opinion. Link opens the Clicks category page, not the product. Search the shade name there.", "Yes - Clicks page claims up to 100%", true),
  row("D020", "Schwarzkopf", "Palette Deluxe", "Dark Warm Brown", "3-0", 3, "Golden / warm", "No", "Permanent", "Quality", 150, "Price seen in Clicks listing - confirm", "https://clicks.co.za/beauty/hair/hair-colour/permanent/c/OH400111", "Link opens the Clicks category page, not the product. Search the shade name there.", "Not confirmed", true),
  row("D021", "Clairol", "Nice'n Easy", "Dark Brown", "4", 4, "Neutral", "No", "Permanent", "Quality", 139, "Price seen in Clicks listing - confirm", "https://clicks.co.za/beauty/hair/hair-colour/permanent/no-ammonia/c/OH400111", "Link opens the Clicks category page, not the product. Search the shade name there.", "Not confirmed", true),
  row("D022", "Clairol", "Nice'n Easy", "Medium Ash Blonde", "8A", 8, "Ash / cool", "No", "Permanent", "Quality", 139, "Price seen in Clicks listing - confirm", "https://clicks.co.za/beauty/hair/hair-colour/permanent/c/OH400111", "Needs a light starting colour. Link opens the Clicks category page, not the product. Search the shade name there.", "Not confirmed", true),
  row("D023", "Revlon", "ColorSilk", "Dark Brown", "30", 4, "Neutral", "No", "Permanent", "Budget", 59.99, "Price seen in Clicks listing - confirm", "https://clicks.co.za/beauty/hair/hair-colour/permanent/no-ammonia/c/OH400111", "Level inferred from name. Budget option. Link opens the Clicks category page, not the product. Search the shade name there.", "Not confirmed", false),
  row("D024", "Revlon", "ColorSilk", "Medium Rich Brown", "47", 5, "Neutral", "No", "Permanent", "Budget", 59.99, "Price seen in Clicks listing - confirm", "https://clicks.co.za/beauty/hair/hair-colour/permanent/c/OH400111", "Budget option. Link opens the Clicks category page, not the product. Search the shade name there.", "Not confirmed", false),
  row("D025", "Revlon", "ColorSilk", "Golden Chestnut Brown", "46", 5, "Golden / warm", "No", "Permanent", "Budget", 59.99, "Price seen in Clicks listing - confirm", "https://clicks.co.za/beauty/hair/hair-colour/permanent/no-ammonia/c/OH400111", "Budget option. Warm tones can pull orange. Link opens the Clicks category page, not the product. Search the shade name there.", "Not confirmed", false),
  row("D026", "Revlon", "ColorSilk", "Dark Blonde", "61", 7, "Neutral", "No", "Permanent", "Budget", 59.99, "Price seen in Clicks listing - confirm", "https://clicks.co.za/beauty/hair/hair-colour/permanent/no-ammonia/c/OH400111", "Budget option. Link opens the Clicks category page, not the product. Search the shade name there.", "Not confirmed", false),
  row("D027", "Renew", "Colour Infusion", "Blue Black", "1.1", 1, "Neutral", "No", "Permanent", "Budget", 76.99, "Price seen in Clicks listing - confirm", "https://clicks.co.za/beauty/hair/hair-colour/permanent/no-ammonia/c/OH400111", "Budget option. Link opens the Clicks category page, not the product. Search the shade name there.", "Not confirmed", false),
  row("D028", "Renew", "Colour Lock", "Burgundy", "3.16", 3, "Red / violet", "Yes", "Permanent", "Budget", 76.99, "Price seen in Clicks listing - confirm", "https://clicks.co.za/beauty/hair/hair-colour/permanent/no-ammonia/c/OH400111", "Red/violet shade. Budget option. Link opens the Clicks category page, not the product. Search the shade name there.", "Not confirmed", false),
  row("D029", "Inecto", "Permanent Colour Crème", "Caramel Blonde", "(confirm on pack)", 8, "Golden / warm", "No", "Permanent", "Budget", 39.99, "Price seen in Clicks listing - confirm", "https://clicks.co.za/beauty/hair/hair-colour/permanent/no-ammonia/c/OH400111", "Level inferred from name. Budget option. Link opens the Clicks category page, not the product. Search the shade name there.", "Not confirmed", false),
];

function row(
  id: string,
  brand: string,
  range: string,
  shadeName: string,
  shadeNo: string,
  level: number | null,
  tone: DyeTone,
  containsRed: ContainsRed,
  type: BoxDye["type"],
  tier: BoxDye["tier"],
  price: number | null,
  priceStatus: string,
  url: string,
  notes: string,
  greyClaim: string,
  showInApp: boolean,
): BoxDye {
  return {
    id,
    brand,
    range,
    shadeName,
    shadeNo,
    level,
    tone,
    containsRed,
    type,
    tier,
    store: "Clicks",
    price,
    priceStatus,
    lastChecked: "2026-11-16",
    url,
    notes,
    greyClaim,
    showInApp,
  };
}

export const DYE_DATABASE: BoxDye[] = ROWS.filter((item) => item.showInApp && item.tier !== "Budget");

export function levelGroup(level: number | null): string {
  if (level == null) return "Confirm level";
  if (level <= 3) return "Black / darkest brown";
  if (level === 4) return "Dark brown";
  if (level === 5) return "Medium brown";
  if (level === 6) return "Light brown";
  if (level === 7) return "Dark blonde";
  if (level === 8) return "Medium blonde";
  return "Light blonde";
}

export function priceLabel(price: number | null): string {
  if (price == null) return "Price not seen — check";
  if (Number.isInteger(price)) return `R${price}`;
  return `R${price.toFixed(2)}`;
}

export function checkedLabel(iso: string): string {
  const [year, month, day] = iso.split("-");
  const names = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  const monthName = names[Number(month) - 1] ?? month;
  return `${Number(day)} ${monthName} ${year}`;
}

export function recheck(iso: string, now = new Date()): boolean {
  const checked = new Date(`${iso}T00:00:00Z`).getTime();
  return (now.getTime() - checked) / 86_400_000 > 90;
}

export function claimsGreyCoverage(item: BoxDye): boolean {
  return item.greyClaim.startsWith("Yes");
}

export function linkLabel(item: BoxDye): string {
  return item.notes.toLowerCase().includes("category page") ? "Find this shade on Clicks" : "View product";
}
