import type { HairProfile } from "./engine.ts";
import {
  DYE_DATABASE,
  claimsGreyCoverage,
  levelGroup,
  type BoxDye,
  type DyeTone,
} from "./dye-database.ts";

export type SwatchTarget = { level: number; tone: DyeTone; name: string };

/** Level and tone for the colour swatches already used to paint the photo. */
export const SWATCH_TARGET: Record<string, SwatchTarget> = {
  "colorsilk-12": { level: 1, tone: "Ash / cool", name: "Blue black" },
  "clicks-infinite-black": { level: 1, tone: "Neutral", name: "Black" },
  "nice-easy-black": { level: 1, tone: "Neutral", name: "Natural black" },
  "colorsilk-30": { level: 4, tone: "Neutral", name: "Dark brown" },
  "excellence-darkest": { level: 2, tone: "Neutral", name: "Darkest brown" },
  "clicks-nutrisse-30": { level: 3, tone: "Neutral", name: "Darkest brown" },
  "nutrisse-412": { level: 4, tone: "Ash / cool", name: "Chocolate brown" },
  "colorsilk-31": { level: 4, tone: "Red / violet", name: "Dark auburn" },
  "colorstay-512": { level: 5, tone: "Ash / cool", name: "Cool medium brown" },
  "nice-easy-5g": { level: 5, tone: "Golden / warm", name: "Golden brown" },
  "renew-565": { level: 5, tone: "Red / violet", name: "Auburn" },
  "clicks-auburn-45": { level: 4, tone: "Red / violet", name: "Auburn" },
  "clicks-glacial": { level: 5, tone: "Ash / cool", name: "Ash brown" },
  "clicks-excellence-5u": { level: 5, tone: "Neutral", name: "Light brown" },
  "clicks-hot-cocoa": { level: 6, tone: "Golden / warm", name: "Warm light brown" },
  "clicks-pref-91": { level: 9, tone: "Ash / cool", name: "Light ash blonde" },
  "pref-very-light": { level: 9, tone: "Neutral", name: "Very light blonde" },
  "pref-1121": { level: 10, tone: "Ash / cool", name: "Ultra-light cool blonde" },
};

const ANSWER_LEVEL: Record<HairProfile["natural"], number | null> = {
  black: 1,
  dark: 4,
  medium: 5,
  light: 6,
  blonde: 8,
  grey: null,
  red: 5,
};

export type DyeRole = "Best match" | "Gentler option" | "Budget option" | "Closest safe home shade";

export type HomeCard = {
  dye: BoxDye;
  role: DyeRole;
  salonRecommended: boolean;
  salonReason: string | null;
};

export type HomeMatch = {
  target: SwatchTarget | null;
  blocked: string | null;
  salonOnly: string | null;
  cards: HomeCard[];
  empty: string | null;
};

function answerLevel(colour: HairProfile["natural"]): number | null {
  return ANSWER_LEVEL[colour];
}

function dyedBefore(profile: HairProfile) {
  return profile.history.some((item) => item === "box" || item === "salon" || item === "balayage" || item === "bleach");
}

function recentChemical(profile: HairProfile) {
  return profile.last === "weeks" && profile.history.some((item) => item === "relaxer" || item === "bleach");
}

function damaged(profile: HairProfile) {
  return profile.problems.some((item) => item === "breakage" || item === "thinning" || item === "dry");
}

function greyHeavy(profile: HairProfile) {
  return profile.grey === "half" || profile.grey === "most";
}

function noRed(profile: HairProfile) {
  return profile.pigment === "yes" || profile.pigment === "avoid";
}

function sameBand(dye: BoxDye, target: SwatchTarget) {
  if (dye.level == null || dye.tone !== target.tone) return false;
  const near = Math.abs(dye.level - target.level) <= 1;
  const group = levelGroup(dye.level) === levelGroup(target.level);
  return near || group;
}

function allowed(profile: HairProfile, dye: BoxDye) {
  if (noRed(profile) && (dye.containsRed === "Yes" || dye.containsRed === "Maybe")) return false;
  if (profile.pigment === "yes" && dye.tone === "Golden / warm") return false;
  if (greyHeavy(profile)) {
    if (dye.tone === "Ash / cool") return false;
    if (!claimsGreyCoverage(dye)) return false;
    const natural = answerLevel(profile.natural) ?? answerLevel(profile.current);
    if (natural != null && dye.level != null && Math.abs(dye.level - natural) > 2) return false;
  }
  if ((profile.age === "forties" || profile.age === "fifties" || profile.age === "sixty") && profile.mood !== "bold" && dye.level === 1) {
    return false;
  }
  return true;
}

function liftBlock(profile: HairProfile, target: SwatchTarget): string | null {
  const current = answerLevel(profile.current);
  const natural = answerLevel(profile.natural) ?? current;
  if (current == null || natural == null) return null;
  const liftFromCurrent = target.level - current;
  const liftFromNatural = target.level - natural;
  if (damaged(profile) && liftFromCurrent > 0) {
    return "Your hair is dry, thin, or breaking, so a box should not lighten it.";
  }
  if (dyedBefore(profile) && liftFromCurrent > 0) {
    return "Your hair is already dyed, so a box can't make it lighter safely.";
  }
  if (liftFromNatural > 2 || liftFromCurrent > 2) {
    return "This colour is more than 2 levels lighter than your hair. A box can't lift that far safely.";
  }
  return null;
}

function darkOnLight(profile: HairProfile, dye: BoxDye): string | null {
  const current = answerLevel(profile.current);
  if (dye.level == null || current == null) return null;
  const veryLight = current >= 8 || profile.history.includes("bleach");
  if (veryLight && current - dye.level > 2) {
    return "Your hair is very light or bleached. Going this dark at home can turn muddy or green. A salon is the safer place, or ask them about a filler first.";
  }
  return null;
}

function rank(dye: BoxDye, target: SwatchTarget) {
  if (dye.level == null) return 0;
  let score = 0;
  if (dye.level === target.level) score += 5;
  else if (Math.abs(dye.level - target.level) <= 1) score += 3;
  if (levelGroup(dye.level) === levelGroup(target.level)) score += 1;
  if (dye.tier === "Quality") score += 1;
  return score;
}

function pickRole(pool: BoxDye[], target: SwatchTarget, role: DyeRole, used: Set<string>): BoxDye | null {
  const open = pool.filter((item) => !used.has(item.id));
  if (role === "Gentler option") {
    const semi = open.filter((item) => item.type === "Semi-permanent" || item.tier === "Quality - gentler");
    return semi.sort((a, b) => rank(b, target) - rank(a, target))[0] ?? null;
  }
  if (role === "Budget option") {
    const budget = open.filter((item) => item.tier === "Budget");
    return budget.sort((a, b) => rank(b, target) - rank(a, target))[0] ?? null;
  }
  const quality = open.filter((item) => item.tier === "Quality" && item.type === "Permanent");
  const source = quality.length > 0 ? quality : open.filter((item) => item.type === "Permanent");
  return source.sort((a, b) => rank(b, target) - rank(a, target))[0] ?? null;
}

function cardsFrom(pool: BoxDye[], target: SwatchTarget, profile: HairProfile, salonOnly: boolean): HomeCard[] {
  const used = new Set<string>();
  const roles: DyeRole[] = salonOnly ? ["Closest safe home shade"] : ["Best match", "Gentler option", "Budget option"];
  const cards: HomeCard[] = [];
  for (const role of roles) {
    const dye = pickRole(pool, target, role === "Closest safe home shade" ? "Best match" : role, used);
    if (!dye) continue;
    used.add(dye.id);
    const dark = darkOnLight(profile, dye);
    cards.push({ dye, role, salonRecommended: Boolean(dark), salonReason: dark });
  }
  if (damaged(profile)) {
    cards.sort((a, b) => Number(b.role === "Gentler option") - Number(a.role === "Gentler option"));
  }
  return cards.slice(0, 3);
}

function safePool(profile: HairProfile, target: SwatchTarget) {
  const current = answerLevel(profile.current);
  return DYE_DATABASE.filter((dye) => {
    if (!allowed(profile, dye) || dye.level == null) return false;
    if (dye.tone !== target.tone) return false;
    if (current == null) return true;
    if (dyedBefore(profile) || damaged(profile)) return dye.level <= current;
    return dye.level <= current + 2;
  });
}

export function matchHome(profile: HairProfile, swatchId: string): HomeMatch {
  const target = SWATCH_TARGET[swatchId] ?? null;
  if (profile.history.includes("henna") || profile.history.includes("metal") || profile.history.includes("keratin")) {
    const bits = [
      profile.history.includes("henna") ? "henna" : null,
      profile.history.includes("keratin") ? "keratin or a smoothing treatment" : null,
      profile.history.includes("metal") ? "metal-based or progressive colour" : null,
    ].filter(Boolean);
    return {
      target,
      blocked: `You have ${bits.join(" and ")}. Do not use a box dye. A salon needs to do a strand test first.`,
      salonOnly: null,
      cards: [],
      empty: null,
    };
  }
  if (recentChemical(profile)) {
    return {
      target,
      blocked: "You had a relaxer, perm, or bleach in the last month. Do not use permanent colour yet. See a salon.",
      salonOnly: null,
      cards: [],
      empty: null,
    };
  }
  if (!target) {
    return {
      target: null,
      blocked: null,
      salonOnly: null,
      cards: [],
      empty: "This swatch has no level on the dye list. I will not guess a box. Ask a salon.",
    };
  }
  const salonReason = liftBlock(profile, target);
  const pool = DYE_DATABASE.filter((dye) => sameBand(dye, target) && allowed(profile, dye));
  if (salonReason) {
    const current = answerLevel(profile.current);
    const cap = current == null ? target.level : dyedBefore(profile) || damaged(profile) ? current : current + 2;
    const aim = Math.min(target.level, cap);
    const safe = safePool(profile, target);
    const cards = cardsFrom(safe, { ...target, level: aim }, profile, true);
    return {
      target,
      blocked: null,
      salonOnly: salonReason,
      cards,
      empty: cards.length === 0 ? "Nothing on the Clicks list is a safe home shade for this. Use the salon option." : null,
    };
  }
  const cards = cardsFrom(pool, target, profile, false);
  if (cards.length === 0 && greyHeavy(profile) && target.tone === "Ash / cool") {
    return {
      target,
      blocked: null,
      salonOnly: null,
      cards: [],
      empty: "Ash shades are a weak grey cover, and no dye here has a grey-coverage claim that starts with Yes. Use the salon option.",
    };
  }
  return {
    target,
    blocked: null,
    salonOnly: null,
    cards,
    empty: cards.length === 0 ? "Nothing on the dye list fits this colour and your rules. Use the salon option." : null,
  };
}
