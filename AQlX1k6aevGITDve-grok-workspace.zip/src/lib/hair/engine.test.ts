import assert from "node:assert/strict";
import test from "node:test";
import { chooseColors, type FaceRead, type HairProfile } from "./engine.ts";

const faceA: FaceRead = { faceShape: "oval", undertone: "cool", skinDepth: "fair", lightingOk: true };
const faceB: FaceRead = { faceShape: "round", undertone: "warm", skinDepth: "deep", lightingOk: true };

function profile(over: Partial<HairProfile>): HairProfile {
  return {
    goal: ["change"],
    age: "thirties",
    eyes: "blue",
    length: "shoulder",
    cut: "no",
    thickness: "medium",
    texture: "straight",
    natural: "blonde",
    current: "blonde",
    grey: "none",
    pigment: "no",
    history: ["never"],
    ends: null,
    last: "never",
    problems: [],
    heat: "sometimes",
    time: "15",
    route: "home",
    budget: "high",
    mood: "natural",
    curls: "no",
    fringe: "no",
    ...over,
  };
}

test("two faces do not get the same colour set", () => {
  const fair = chooseColors(profile({}), faceA).colors.map((item) => item.dye.id);
  const deep = chooseColors(
    profile({
      eyes: "brown",
      natural: "black",
      current: "black",
      age: "fifties",
      pigment: "yes",
      history: ["box"],
      mood: "natural",
    }),
    faceB,
  ).colors.map((item) => item.dye.id);
  assert.ok(fair.length >= 6);
  assert.ok(deep.length >= 6);
  assert.notDeepEqual(fair, deep);
});

test("red pigmentation removes warm and red dyes", () => {
  const colors = chooseColors(
    profile({ pigment: "yes", current: "medium", natural: "medium", eyes: "brown" }),
    faceB,
  ).colors;
  for (const color of colors) {
    const text = `${color.dye.shade} ${color.dye.product} ${color.dye.undertone}`;
    assert.equal(/auburn|mahogany|copper|cocoa|burgundy/i.test(text), false);
    assert.notEqual(color.dye.undertone, "warm");
  }
});

test("poor light does not invent colours", () => {
  const result = chooseColors(profile({}), { ...faceA, lightingOk: false });
  assert.equal(result.colors.length, 0);
  assert.match(result.note ?? "", /Retake/);
});

test("box dye on dark hair marks blonde as salon only", () => {
  const colors = chooseColors(
    profile({ current: "dark", natural: "dark", history: ["box"], eyes: "brown", pigment: "no" }),
    { ...faceB, skinDepth: "medium", undertone: "neutral" },
  ).colors;
  const blonde = colors.find((item) => item.dye.depth === "blonde" || item.dye.depth === "platinum");
  if (blonde) assert.equal(blonde.salonOnly, true);
  assert.ok(colors.some((item) => item.best));
});
