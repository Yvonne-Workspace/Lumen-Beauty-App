function clip(value: unknown, max: number) {
  if (typeof value !== "string") return "";
  return value.replace(/\s+/g, " ").trim().slice(0, max);
}

function asRecord(value: unknown): Record<string, unknown> | null {
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  return value as Record<string, unknown>;
}

export function explainStudioError(status: number, json: unknown): string {
  const record = asRecord(json);
  const err = record ? asRecord(record.error) : null;
  const raw = clip(typeof record?.error === "string" ? record.error : err?.message ?? record?.message, 240);
  const code = clip(record?.code, 80);
  const blob = `${status} ${code} ${raw}`.toLowerCase();
  if (/minor|under 18|child/.test(blob)) return "Lumen only reads adult portraits.";
  if (/spending-limit|out of credits|need a grok subscription|credits/.test(blob)) {
    return "The picture studio has no credits left, so it cannot read the photo or make the looks.";
  }
  if (status === 413 || /too large|payload|entity too large/.test(blob)) return "The photo may be too large.";
  if (status === 429 || status >= 500 || /rate limit|overloaded|capacity|busy/.test(blob)) {
    return "The picture studio is busy. Try again in a minute.";
  }
  if (status === 0 || /network|econn|fetch failed|connection/.test(blob)) return "Check your connection.";
  return raw || "The picture studio is busy. Try again in a minute.";
}

export function explainThrown(error: unknown): string {
  const text = error instanceof Error ? error.message : "";
  if (/too large|payload|413/.test(text.toLowerCase())) return "The photo may be too large.";
  if (/abort|timeout|busy|429|503/.test(text.toLowerCase())) return "The picture studio is busy. Try again in a minute.";
  if (/failed to fetch|network|econn|load failed|connection/.test(text.toLowerCase())) return "Check your connection.";
  return "Check your connection.";
}
