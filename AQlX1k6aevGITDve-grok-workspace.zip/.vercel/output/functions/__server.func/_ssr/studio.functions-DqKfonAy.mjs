import { i as string, r as object } from "../_libs/zod.mjs";
import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/studio.functions-DqKfonAy.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var imageField = string().min(32).max(28e5).refine((value) => /^data:image\/(jpeg|png|webp);base64,/.test(value), { message: "Upload a JPEG, PNG, or WebP photo." });
var readInput = object({ imageDataUrl: imageField });
var previewInput = object({
	imageDataUrl: imageField,
	styleName: string().trim().min(1).max(80),
	styleEdit: string().trim().min(1).max(420),
	colorName: string().trim().min(1).max(80),
	colorEdit: string().trim().min(1).max(420)
});
var READING_PROMPT = `Look at this portrait.
If there is no clearly visible human face, return {"blocked":true,"reason":"noface"}.
If the person appears to be under 18, return {"blocked":true,"reason":"minor"}.
Otherwise return only this JSON:
{
  "blocked": false,
  "faceShape": "oval | round | square | heart | oblong | diamond",
  "undertone": "warm | cool | neutral",
  "contrast": "low | medium | high",
  "currentHair": "what you actually see",
  "summary": "two specific sentences of cut and color advice for this face",
  "styles": [4 objects],
  "colors": [4 objects],
  "avoid": ["short phrase", "short phrase"]
}
Each style object: {"id":"s1","name":"at most four words","why":"one sentence tied to this face shape","edit":"a concrete haircut a photo editor can apply, 20 to 40 words, no color words"}
Each color object: {"id":"c1","name":"two or three words","hex":"#RRGGBB","why":"one sentence tied to undertone and contrast","edit":"a concrete hair-color description, 15 to 30 words"}
Recommend looks that would suit this person. Vary the lengths. Do not make every option a copy of the hair already in the photo. No preamble, no markdown.`;
var UNAVAILABLE = "Portrait reading is unavailable right now. Try again in a moment.";
function clip(value, max) {
	if (typeof value !== "string") return "";
	return value.replace(/\s+/g, " ").trim().slice(0, max);
}
function asRecord(value) {
	if (!value || typeof value !== "object" || Array.isArray(value)) return null;
	return value;
}
function errorDetail(json, status) {
	const record = asRecord(json);
	const message = clip((record ? asRecord(record.error) : null)?.message ?? record?.message, 180);
	if (/minor|under 18|child/i.test(message)) return "Lumen only reads adult portraits.";
	if (status === 0) return message || "Portrait reading is unavailable right now.";
	return "The studio could not finish that. Try again.";
}
async function postXai(path, body) {
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return {
		ok: false,
		status: 0,
		message: UNAVAILABLE
	};
	let response;
	try {
		response = await fetch(`https://api.x.ai/v1${path}`, {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				Authorization: `Bearer ${apiKey}`
			},
			body: JSON.stringify(body),
			signal: AbortSignal.timeout(9e4)
		});
	} catch {
		return {
			ok: false,
			status: 0,
			message: "The studio timed out. Try once more."
		};
	}
	const text = await response.text();
	let json = null;
	try {
		json = text ? JSON.parse(text) : null;
	} catch {
		json = null;
	}
	if (!response.ok) return {
		ok: false,
		status: response.status,
		message: errorDetail(json, response.status)
	};
	return {
		ok: true,
		json
	};
}
function messageText(json) {
	const choices = asRecord(json)?.choices;
	if (!Array.isArray(choices) || !choices[0]) return "";
	const message = asRecord(choices[0])?.message;
	const content = asRecord(message)?.content ?? message?.content;
	if (typeof content === "string") return content;
	if (!Array.isArray(content)) return "";
	return content.map((part) => {
		const row = asRecord(part);
		return typeof row?.text === "string" ? row.text : "";
	}).join("");
}
function parseReading(raw) {
	const start = raw.indexOf("{");
	const end = raw.lastIndexOf("}");
	if (start < 0 || end <= start) return {
		ok: false,
		message: "The reading came back unreadable. Try again."
	};
	let parsed;
	try {
		parsed = JSON.parse(raw.slice(start, end + 1));
	} catch {
		return {
			ok: false,
			message: "The reading came back unreadable. Try again."
		};
	}
	const data = asRecord(parsed);
	if (!data) return {
		ok: false,
		message: "The reading came back unreadable. Try again."
	};
	if (data.blocked === true) {
		if (clip(data.reason, 40) === "minor") return {
			ok: false,
			message: "Lumen only reads adult portraits. Upload a photo of an adult."
		};
		return {
			ok: false,
			message: "No clear face in that photo. Use a front-facing selfie in even light."
		};
	}
	const styles = Array.isArray(data.styles) ? data.styles : [];
	const colors = Array.isArray(data.colors) ? data.colors : [];
	const cleanStyles = [];
	for (const item of styles) {
		const row = asRecord(item);
		if (!row) continue;
		const name = clip(row.name, 48);
		const why = clip(row.why, 220);
		const edit = clip(row.edit, 400);
		if (!name || !why || !edit) continue;
		cleanStyles.push({
			id: `s${cleanStyles.length + 1}`,
			name,
			why,
			edit
		});
		if (cleanStyles.length === 4) break;
	}
	const cleanColors = [];
	for (const item of colors) {
		const row = asRecord(item);
		if (!row) continue;
		const name = clip(row.name, 48);
		const why = clip(row.why, 220);
		const edit = clip(row.edit, 400);
		const hexRaw = clip(row.hex, 7);
		const hex = /^#[0-9A-Fa-f]{6}$/.test(hexRaw) ? hexRaw : "#5c4638";
		if (!name || !why || !edit) continue;
		cleanColors.push({
			id: `c${cleanColors.length + 1}`,
			name,
			hex,
			why,
			edit
		});
		if (cleanColors.length === 4) break;
	}
	if (cleanStyles.length < 2 || cleanColors.length < 2) return {
		ok: false,
		message: "The reading was too thin to use. Try the photo again."
	};
	const avoid = Array.isArray(data.avoid) ? data.avoid.map((item) => clip(item, 80)).filter(Boolean).slice(0, 3) : [];
	return {
		ok: true,
		reading: {
			faceShape: clip(data.faceShape, 32) || "unspecified",
			undertone: clip(data.undertone, 32) || "unspecified",
			contrast: clip(data.contrast, 32) || "unspecified",
			currentHair: clip(data.currentHair, 160) || "Not described",
			summary: clip(data.summary, 420) || "A softer shape and a color close to your natural depth will sit best.",
			styles: cleanStyles,
			colors: cleanColors,
			avoid
		}
	};
}
function imageUrlFrom(json) {
	const record = asRecord(json);
	const data = record?.data;
	if (Array.isArray(data)) {
		const first = asRecord(data[0]);
		if (typeof first?.url === "string" && first.url.startsWith("http")) return first.url;
		if (typeof first?.b64_json === "string" && first.b64_json.length > 32) return `data:image/jpeg;base64,${first.b64_json}`;
	}
	if (typeof record?.url === "string" && record.url.startsWith("http")) return record.url;
	return null;
}
var jobs = /* @__PURE__ */ new Map();
function keepAlive(work) {
	const safe = work.catch(() => void 0);
	const host = globalThis;
	if (typeof host.waitUntil === "function") host.waitUntil(safe);
}
function finish(id, result) {
	jobs.set(id, {
		state: "done",
		result,
		at: Date.now()
	});
	const cutoff = Date.now() - 6e5;
	for (const [key, job] of jobs) if (job.state === "done" && job.at < cutoff) jobs.delete(key);
}
function enqueue(work) {
	const id = crypto.randomUUID();
	jobs.set(id, { state: "pending" });
	keepAlive(work.then((result) => finish(id, result), () => finish(id, {
		ok: false,
		message: "The studio could not finish that. Try again."
	})));
	return { jobId: id };
}
async function runRead(imageDataUrl) {
	const first = await postXai("/chat/completions", {
		model: "grok-4.5",
		temperature: .3,
		max_tokens: 1400,
		messages: [{
			role: "system",
			content: "You read adult portraits for haircut and hair-color advice. Reply with JSON only."
		}, {
			role: "user",
			content: [{
				type: "text",
				text: READING_PROMPT
			}, {
				type: "image_url",
				image_url: { url: imageDataUrl }
			}]
		}]
	});
	if (!first.ok) return {
		ok: false,
		message: first.message
	};
	const text = messageText(first.json);
	if (!text) return {
		ok: false,
		message: "The reading came back empty. Try again."
	};
	return parseReading(text);
}
async function inlineImage(url) {
	if (url.startsWith("data:")) return url;
	try {
		const response = await fetch(url, { signal: AbortSignal.timeout(2e4) });
		if (!response.ok) return url;
		const bytes = Buffer.from(await response.arrayBuffer());
		if (bytes.byteLength > 35e5) return url;
		return `data:${(response.headers.get("content-type") || "image/jpeg").split(";")[0] || "image/jpeg"};base64,${bytes.toString("base64")}`;
	} catch {
		return url;
	}
}
async function runPreview(data) {
	const edited = await postXai("/images/edits", {
		model: "grok-imagine-image-2.0",
		prompt: [
			"Photorealistic edit. Change only the hair.",
			"Keep the same person, face, identity, age, expression, skin, eyes, clothing, background, lighting, pose, and framing.",
			"Do not add people, text, logos, or watermarks. Do not change the body.",
			`Haircut: ${data.styleEdit}`,
			`Hair color: ${data.colorEdit} The color is called ${data.colorName}.`,
			"The hair should meet the scalp naturally and match the existing light."
		].join(" "),
		image: {
			type: "image_url",
			url: data.imageDataUrl
		},
		response_format: "url"
	});
	if (!edited.ok) return {
		ok: false,
		message: edited.message
	};
	const remote = imageUrlFrom(edited.json);
	if (!remote) return {
		ok: false,
		message: "The look was painted, but the image did not come back. Try again."
	};
	return {
		ok: true,
		imageUrl: await inlineImage(remote)
	};
}
var readPortrait_createServerFn_handler = createServerRpc({
	id: "829bbd9341bd491bc3a60e48d93cf505a7c3266b4954c5300573250b5787e634",
	name: "readPortrait",
	filename: "src/lib/hair/studio.functions.ts"
}, (opts) => readPortrait.__executeServer(opts));
var readPortrait = createServerFn({ method: "POST" }).validator((input) => readInput.parse(input)).handler(readPortrait_createServerFn_handler, async ({ data }) => enqueue(runRead(data.imageDataUrl)));
var previewLook_createServerFn_handler = createServerRpc({
	id: "54b934eda3802a46675c22de7962aa31156f09761a399ae68d4d5ac6be7140fc",
	name: "previewLook",
	filename: "src/lib/hair/studio.functions.ts"
}, (opts) => previewLook.__executeServer(opts));
var previewLook = createServerFn({ method: "POST" }).validator((input) => previewInput.parse(input)).handler(previewLook_createServerFn_handler, async ({ data }) => enqueue(runPreview(data)));
var studioJob_createServerFn_handler = createServerRpc({
	id: "d400fa8c6d1760fa1efc24afa18ec356cf6284a2ed48e1e1a89e5c4bf547ebb9",
	name: "studioJob",
	filename: "src/lib/hair/studio.functions.ts"
}, (opts) => studioJob.__executeServer(opts));
var studioJob = createServerFn({ method: "POST" }).validator((input) => object({ jobId: string().uuid() }).parse(input)).handler(studioJob_createServerFn_handler, async ({ data }) => {
	const job = jobs.get(data.jobId);
	if (!job) return {
		pending: false,
		result: {
			ok: false,
			message: "That step expired. Try again."
		}
	};
	if (job.state === "pending") return { pending: true };
	return {
		pending: false,
		result: job.result
	};
});
//#endregion
export { previewLook_createServerFn_handler, readPortrait_createServerFn_handler, studioJob_createServerFn_handler };
