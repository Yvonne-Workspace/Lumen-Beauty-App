export type PixelIssue = "dark" | "shadow" | "yellow" | "blur";

export async function scanPixels(dataUrl: string): Promise<PixelIssue[]> {
  const image = await new Promise<HTMLImageElement>((resolve, reject) => {
    const next = new Image();
    next.onload = () => resolve(next);
    next.onerror = () => reject(new Error("Could not read that photo."));
    next.src = dataUrl;
  });
  const canvas = document.createElement("canvas");
  const size = 64;
  canvas.width = size;
  canvas.height = size;
  const context = canvas.getContext("2d", { willReadFrequently: true });
  if (!context) return [];
  context.drawImage(image, 0, 0, size, size);
  const { data } = context.getImageData(0, 0, size, size);
  let lum = 0;
  let left = 0;
  let right = 0;
  let red = 0;
  let blue = 0;
  const count = size * size;
  const half = count / 2;
  const gray = new Float32Array(count);
  for (let i = 0; i < count; i += 1) {
    const offset = i * 4;
    const r = data[offset] ?? 0;
    const g = data[offset + 1] ?? 0;
    const b = data[offset + 2] ?? 0;
    const y = 0.2126 * r + 0.7152 * g + 0.0722 * b;
    gray[i] = y;
    lum += y;
    red += r;
    blue += b;
    if (i % size < size / 2) left += y;
    else right += y;
  }
  let edges = 0;
  for (let y = 1; y < size - 1; y += 1) {
    for (let x = 1; x < size - 1; x += 1) {
      const center = gray[y * size + x] ?? 0;
      const around =
        (gray[y * size + x - 1] ?? 0) +
        (gray[y * size + x + 1] ?? 0) +
        (gray[(y - 1) * size + x] ?? 0) +
        (gray[(y + 1) * size + x] ?? 0);
      edges += Math.abs(4 * center - around);
    }
  }
  const issues: PixelIssue[] = [];
  if (lum / count < 55) issues.push("dark");
  if (Math.abs(left - right) / half > 28) issues.push("shadow");
  if (red / count - blue / count > 32 && red / count > 90) issues.push("yellow");
  if (edges / ((size - 2) * (size - 2)) < 10) issues.push("blur");
  return issues;
}

export const PIXEL_TEXT: Record<PixelIssue, string> = {
  dark: "The photo is too dark.",
  shadow: "One side of the face is in shadow.",
  yellow: "The light looks yellow.",
  blur: "The photo looks blurry.",
};
