import { useEffect, useRef, useState } from "react";
import { LoaderCircle } from "lucide-react";
import { frameToPortrait } from "@/lib/portrait";

export function CameraCapture({
  onClose,
  onShot,
}: {
  onClose: () => void;
  onShot: (dataUrl: string) => void;
}) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [facing, setFacing] = useState<"user" | "environment">("user");
  const [error, setError] = useState<string | null>(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;
    let stream: MediaStream | null = null;
    let cancelled = false;
    setReady(false);
    setError(null);

    if (!navigator.mediaDevices?.getUserMedia) {
      setError("This browser cannot open a camera here. Upload a photo instead.");
      return;
    }

    const timer = window.setTimeout(() => {
      if (!cancelled) setError("The camera did not start. Allow it if the browser asks, or upload a photo.");
    }, 12000);

    void navigator.mediaDevices
      .getUserMedia({
        audio: false,
        video: { facingMode: facing, width: { ideal: 1280 }, height: { ideal: 1600 } },
      })
      .then(async (next) => {
        if (cancelled) {
          next.getTracks().forEach((track) => track.stop());
          return;
        }
        stream = next;
        video.srcObject = next;
        await video.play();
        if (!cancelled) {
          window.clearTimeout(timer);
          setError(null);
          setReady(true);
        }
      })
      .catch((reason: unknown) => {
        if (cancelled) return;
        window.clearTimeout(timer);
        const name = reason instanceof DOMException ? reason.name : "";
        if (name === "NotAllowedError" || name === "SecurityError") {
          setError("Camera permission was blocked. You can still upload a photo.");
        } else if (name === "NotFoundError" || name === "OverconstrainedError") {
          setError("No camera was found on this device. Upload a photo instead.");
        } else {
          setError("The camera could not start. Upload a photo instead.");
        }
      });

    return () => {
      cancelled = true;
      window.clearTimeout(timer);
      stream?.getTracks().forEach((track) => track.stop());
      video.srcObject = null;
    };
  }, [facing]);

  function shoot() {
    const video = videoRef.current;
    if (!video || !ready) return;
    try {
      onShot(frameToPortrait(video, facing === "user"));
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Could not take that photo.");
    }
  }

  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-ink/55 p-4" role="presentation" onClick={onClose}>
      <div
        className="panel w-full max-w-md p-4"
        role="dialog"
        aria-modal="true"
        aria-labelledby="camera-title"
        onClick={(event) => event.stopPropagation()}
      >
        <h2 id="camera-title" className="text-sm font-medium text-ink">
          Take a photo
        </h2>
        <p className="mt-1 text-sm text-stone">Face the light. Eyes open. Just you in the frame.</p>
        <div className="frame mt-3 bg-char">
          <video
            ref={videoRef}
            className="block aspect-[3/4] w-full object-cover"
            style={facing === "user" ? { transform: "scaleX(-1)" } : undefined}
            autoPlay
            muted
            playsInline
          />
          {!ready && !error ? (
            <div className="absolute inset-0 grid place-items-center text-sm text-char-fg">
              <span className="inline-flex items-center gap-2 rounded-full bg-char px-3 py-2">
                <LoaderCircle className="size-4 animate-spin" aria-hidden="true" />
                Opening the camera
              </span>
            </div>
          ) : null}
        </div>
        {error ? <p className="note mt-3">{error}</p> : null}
        <div className="mt-3 flex flex-wrap gap-2">
          <button type="button" className="btn btn-primary" disabled={!ready} onClick={shoot}>
            Use this photo
          </button>
          <button type="button" className="btn btn-quiet" onClick={() => setFacing((current) => (current === "user" ? "environment" : "user"))}>
            Flip camera
          </button>
          <button type="button" className="btn btn-quiet" onClick={onClose}>
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
}
