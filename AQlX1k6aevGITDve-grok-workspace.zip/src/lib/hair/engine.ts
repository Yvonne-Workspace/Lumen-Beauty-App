import { HAIR_DYES, type HairDye } from "./dyes.ts";

export const AGES = [
  { id: "under30", label: "Under 30" },
  { id: "thirties", label: "30s" },
  { id: "forties", label: "40s" },
  { id: "fifties", label: "50s" },
  { id: "sixty", label: "60+" },
] as const;

export const EYES = [
  { id: "brown", label: "Brown" },
  { id: "hazel", label: "Hazel" },
  { id: "green", label: "Green" },
  { id: "blue", label: "Blue" },
  { id: "grey", label: "Grey" },
] as const;

export const GOALS = [
  { id: "change", label: "Change my look" },
  { id: "younger", label: "Look younger" },
  { id: "eyes", label: "Make my eyes pop" },
  { id: "grey", label: "Cover grey" },
  { id: "grow", label: "Grow my hair" },
  { id: "easy", label: "Low maintenance" },
] as const;

export const LENGTHS = [
  { id: "ear", label: "Above the ear" },
  { id: "chin", label: "At the chin" },
  { id: "shoulder", label: "At the shoulders" },
  { id: "long", label: "Below the shoulders" },
] as const;

export const CUTS = [
  { id: "no", label: "No. Keep my length" },
  { id: "trim", label: "A trim only" },
  { id: "shorter", label: "Shorter is fine" },
  { id: "suit", label: "What suits my face" },
] as const;

export const THICKNESS = [
  { id: "fine", label: "Fine" },
  { id: "medium", label: "Medium" },
  { id: "thick", label: "Thick" },
] as const;

export const TEXTURES = [
  { id: "straight", label: "Straight" },
  { id: "wavy", label: "Wavy" },
  { id: "curly", label: "Curly" },
  { id: "coily", label: "Coily" },
] as const;

export const HAIR_COLOURS = [
  { id: "black", label: "Black" },
  { id: "dark", label: "Dark brown" },
  { id: "medium", label: "Medium brown" },
  { id: "light", label: "Light brown" },
  { id: "blonde", label: "Blonde" },
  { id: "grey", label: "Grey or white" },
  { id: "red", label: "Red or copper" },
] as const;

export const GREYS = [
  { id: "none", label: "None" },
  { id: "some", label: "A few" },
  { id: "half", label: "About half" },
  { id: "most", label: "Mostly grey" },
] as const;

export const PIGMENTS = [
  { id: "no", label: "No" },
  { id: "yes", label: "Yes, red or orange shows" },
  { id: "avoid", label: "I do not want red" },
] as const;

export const HISTORIES = [
  { id: "never", label: "Never coloured", tip: "No dye, henna, or bleach." },
  { id: "box", label: "Box dye" },
  { id: "salon", label: "Salon colour" },
  { id: "bleach", label: "Bleach" },
  { id: "balayage", label: "Balayage", tip: "Colour painted by hand. Darker at the root, lighter or redder at the ends." },
  { id: "henna", label: "Henna" },
  { id: "relaxer", label: "Relaxer or perm" },
  { id: "keratin", label: "Keratin or smoothing treatment" },
  { id: "metal", label: "Metal-based or progressive colour (like Grecian-type restorers)" },
] as const;

export const ENDS = [
  { id: "dark", label: "Dark" },
  { id: "light", label: "Light brown" },
  { id: "red", label: "Red" },
  { id: "blonde", label: "Blonde" },
] as const;

export const LASTS = [
  { id: "never", label: "Never" },
  { id: "weeks", label: "In the last month" },
  { id: "months", label: "A few months ago" },
  { id: "year", label: "A year ago or more" },
] as const;

export const PROBLEMS = [
  { id: "dry", label: "Dry or frizzy" },
  { id: "breakage", label: "Breakage" },
  { id: "thinning", label: "Thinning" },
  { id: "slow", label: "Slow growth" },
  { id: "oily", label: "Oily scalp" },
  { id: "itchy", label: "Itchy scalp" },
] as const;

export const HEATS = [
  { id: "never", label: "Never" },
  { id: "sometimes", label: "Sometimes" },
  { id: "daily", label: "Most days" },
] as const;

export const TIMES = [
  { id: "5", label: "Under 5 minutes" },
  { id: "15", label: "About 15 minutes" },
  { id: "30", label: "30 minutes or more" },
] as const;

export const ROUTES = [
  { id: "home", label: "At home, with a box" },
  { id: "salon", label: "At a salon" },
] as const;

export const BUDGETS = [
  { id: "under150", label: "Under R150" },
  { id: "mid", label: "R150 to R250" },
  { id: "high", label: "Over R250 is fine" },
] as const;

export const MOODS = [
  { id: "natural", label: "Natural-looking" },
  { id: "bold", label: "Bolder" },
] as const;

export const YESNO = [
  { id: "yes", label: "Yes" },
  { id: "no", label: "No" },
] as const;

type Id<T extends readonly { id: string }[]> = T[number]["id"];

export type HairProfile = {
  goal: Id<typeof GOALS>[];
  age: Id<typeof AGES>;
  eyes: Id<typeof EYES>;
  length: Id<typeof LENGTHS>;
  cut: Id<typeof CUTS>;
  thickness: Id<typeof THICKNESS>;
  texture: Id<typeof TEXTURES>;
  natural: Id<typeof HAIR_COLOURS>;
  current: Id<typeof HAIR_COLOURS>;
  grey: Id<typeof GREYS>;
  pigment: Id<typeof PIGMENTS>;
  history: Id<typeof HISTORIES>[];
  ends: Id<typeof ENDS> | null;
  last: Id<typeof LASTS>;
  problems: Id<typeof PROBLEMS>[];
  heat: Id<typeof HEATS>;
  time: Id<typeof TIMES>;
  route: Id<typeof ROUTES>;
  budget: Id<typeof BUDGETS>;
  mood: Id<typeof MOODS>;
  curls: "yes" | "no";
  fringe: "yes" | "no";
};

export type FaceRead = {
  faceShape: "oval" | "round" | "square" | "heart" | "oblong" | "diamond" | "unclear";
  undertone: "warm" | "cool" | "neutral" | "unknown";
  skinDepth: "fair" | "medium" | "deep" | "unknown";
  lightingOk: boolean;
};

export type EngineColor = {
  dye: HairDye;
  why: string;
  best: boolean;
  salonOnly: boolean;
};

export type EngineLook = {
  id: string;
  name: string;
  why: string;
  edit: string;
  best: boolean;
  lengthPlan: "keep" | "trim" | "shorter" | "suit";
};

export type Verdict = { verdict: "yes" | "maybe" | "no"; reason: string };

const DEPTH_RANK: Record<HairDye["depth"], number> = {
  black: 0,
  dark: 1,
  medium: 2,
  light: 3,
  blonde: 4,
  platinum: 5,
};

const COLOUR_RANK: Record<HairProfile["current"], number> = {
  black: 0,
  dark: 1,
  medium: 2,
  light: 3,
  blonde: 4,
  grey: 2,
  red: 2,
};

const RED_WORDS = /auburn|mahogany|copper|cocoa|burgundy|red/i;

export const BOX_APPLY =
  "Do a patch test 48 hours before you colour. Read the leaflet in the box for the exact time. A box dye cannot lift hair that is already coloured. Do not use it on eyebrows or lashes.";

export function noRed(profile: HairProfile) {
  return profile.pigment === "yes" || profile.pigment === "avoid";
}

function previouslyColored(profile: HairProfile) {
  return profile.history.some((item) => item === "box" || item === "salon" || item === "bleach" || item === "balayage" || item === "henna");
}

function isRedDye(dye: HairDye) {
  return RED_WORDS.test(`${dye.shade} ${dye.product} ${dye.edit}`);
}

function priceNumber(price: string) {
  const match = price.replace(/[^\d.]/g, "");
  const value = Number(match);
  return Number.isFinite(value) ? value : 0;
}

export function salonOnly(profile: HairProfile, dye: HairDye) {
  if (profile.history.includes("henna")) return true;
  if (profile.route !== "home") return false;
  const lift = DEPTH_RANK[dye.depth] - COLOUR_RANK[profile.current];
  if (previouslyColored(profile)) return lift > 0;
  return lift > 1;
}

function scoreDye(profile: HairProfile, face: FaceRead, dye: HairDye) {
  let score = 0;
  const rank = DEPTH_RANK[dye.depth];
  const current = COLOUR_RANK[profile.current];
  const greyTarget = profile.grey === "most" || profile.grey === "half" || profile.goal.includes("grey") ? Math.max(0, current - 1) : current;
  score += 6 - Math.abs(rank - greyTarget) * 2;
  if (face.undertone !== "unknown" && dye.undertone === face.undertone) score += 3;
  if (face.undertone === "unknown" && dye.undertone === "neutral") score += 1;
  if (noRed(profile) && dye.undertone === "cool") score += 2;
  if (profile.eyes === "brown" && (dye.depth === "dark" || dye.depth === "medium")) score += 2;
  if (profile.eyes === "hazel" && dye.undertone !== "cool") score += 1;
  if ((profile.eyes === "green" || profile.eyes === "blue" || profile.eyes === "grey") && (dye.depth === "medium" || dye.depth === "dark")) {
    score += 2;
  }
  if (face.skinDepth === "deep" && (dye.depth === "blonde" || dye.depth === "platinum")) score -= 5;
  if (face.skinDepth === "fair" && dye.depth === "black") score -= 2;
  if (face.skinDepth === "deep" && (dye.depth === "black" || dye.depth === "dark")) score += 2;
  if ((profile.age === "fifties" || profile.age === "sixty") && profile.mood === "natural" && (dye.depth === "blonde" || dye.depth === "platinum")) {
    score -= 3;
  }
  if (profile.mood === "bold" && !noRed(profile) && dye.undertone === "warm") score += 2;
  if (profile.mood === "natural" && dye.undertone === "neutral") score += 1;
  if (profile.goal.includes("grey") && rank <= 1) score += 3;
  if (profile.goal.includes("easy") && dye.depth !== "platinum") score += 1;
  const price = priceNumber(dye.price);
  if (profile.budget === "under150" && price > 0 && price <= 150) score += 2;
  if (profile.budget === "high" && price >= 200) score += 1;
  if (profile.history.includes("bleach") && rank <= 1) score -= 4;
  if ((profile.problems.includes("breakage") || profile.problems.includes("thinning")) && rank >= 4) score -= 4;
  return score;
}

function whyFor(profile: HairProfile, face: FaceRead, dye: HairDye, homeSafe: boolean) {
  if (profile.history.includes("henna")) {
    return "You used henna. A box dye can react badly with it. Show this shade name to a salon and ask before you colour. Check in store only if they say it is safe.";
  }
  if (!homeSafe) {
    return `This is lighter than a box can safely do on hair that is already ${profile.current}. Salon only.`;
  }
  if (noRed(profile)) {
    return "Ash or neutral, so red and copper stay out.";
  }
  if (profile.goal.includes("grey") || profile.grey === "most" || profile.grey === "half") {
    return "Dark enough to cover grey without a flat black line.";
  }
  if (face.undertone === "unknown") {
    return "Chosen from your eye colour, current colour, and age. Skin tone was not read from this photo.";
  }
  if (profile.eyes === "green" || profile.eyes === "blue" || profile.eyes === "grey") {
    return "Enough contrast for your eye colour.";
  }
  return "Close to a depth your hair can hold, for your skin and your goal.";
}

export function chooseColors(profile: HairProfile, face: FaceRead): { colors: EngineColor[]; note: string | null } {
  if (!face.lightingOk) {
    return { colors: [], note: "The light in the photo is too poor to read your skin tone. Retake it. I will not guess a colour." };
  }
  const blocked = noRed(profile);
  const fragile = profile.problems.includes("breakage") || profile.problems.includes("thinning") || profile.problems.includes("slow");
  const pool = HAIR_DYES.filter((dye) => {
    if (blocked && (dye.undertone === "warm" || isRedDye(dye))) return false;
    if (fragile && (dye.depth === "blonde" || dye.depth === "platinum")) return false;
    if (profile.history.includes("bleach") && (dye.depth === "black" || dye.depth === "dark")) return false;
    return true;
  });
  const ranked = [...pool].sort((a, b) => scoreDye(profile, face, b) - scoreDye(profile, face, a) || a.id.localeCompare(b.id));
  const picked = ranked.slice(0, 8);
  const homeSafe = picked.filter((dye) => !salonOnly(profile, dye));
  const bestId = (profile.route === "home" ? homeSafe[0] ?? picked[0] : picked[0])?.id;
  const colors = picked.map((dye) => {
    const safe = !salonOnly(profile, dye);
    return {
      dye,
      why: whyFor(profile, face, dye, safe),
      best: dye.id === bestId,
      salonOnly: !safe,
    };
  });
  const note =
    colors.length < 6
      ? "These are the only shades on the Clicks and Dis-Chem shelf that fit. I will not invent more."
      : profile.history.includes("henna")
        ? "Henna is on your hair. Do not buy a box dye for it."
        : null;
  return { colors, note };
}

const PLACE: Record<HairProfile["length"], { end: string; name: string }> = {
  ear: { end: "above the ear", name: "Above-ear" },
  chin: { end: "at the chin", name: "Chin-length" },
  shoulder: { end: "at the collarbone", name: "Collarbone" },
  long: { end: "below the shoulders", name: "Below-shoulder" },
};

function shorterPlace(length: HairProfile["length"]) {
  if (length === "long") return PLACE.shoulder;
  if (length === "shoulder") return PLACE.chin;
  if (length === "chin") return PLACE.ear;
  return PLACE.ear;
}

function suitPlace(face: FaceRead["faceShape"], length: HairProfile["length"]) {
  if (face === "round" || face === "square") return length === "ear" ? PLACE.chin : PLACE[length];
  if (face === "oblong" || face === "diamond") return length === "long" || length === "shoulder" ? PLACE.shoulder : PLACE[length];
  if (face === "heart") return PLACE.chin;
  return PLACE[length];
}

export function curlVerdict(profile: HairProfile): Verdict {
  if (profile.curls === "no") {
    return { verdict: "no", reason: "You said you do not want to see curls or waves." };
  }
  if (profile.texture === "curly" || profile.texture === "coily") {
    return { verdict: "yes", reason: "You already have curl. The preview wears it loose. It is not a new perm." };
  }
  if (profile.history.includes("relaxer")) {
    return { verdict: "no", reason: "A curl perm on relaxed hair can break it. I will not show that." };
  }
  if (profile.problems.includes("breakage") || profile.history.includes("bleach")) {
    return { verdict: "maybe", reason: "Heatless waves only. A chemical perm is a bad idea on hair that is damaged or bleached." };
  }
  return { verdict: "yes", reason: "Loose waves can work. This is styling, not a perm." };
}

export function fringeVerdict(profile: HairProfile, face: FaceRead["faceShape"]): Verdict {
  if (profile.fringe === "no") {
    return { verdict: "no", reason: "You said you do not want a fringe." };
  }
  if (profile.texture === "coily") {
    return { verdict: "maybe", reason: "A fringe on coily hair will not sit like straight-hair bangs. A stylist has to cut it." };
  }
  if (face === "heart" || face === "oblong") {
    return { verdict: "yes", reason: face === "heart" ? "A soft fringe balances a wider forehead." : "A fringe shortens a long face." };
  }
  if (face === "round") {
    return { verdict: "maybe", reason: "A full fringe can widen a round face. A side fringe is the only one to try." };
  }
  if (face === "unclear") {
    return { verdict: "maybe", reason: "The face shape was not clear enough for a firm yes." };
  }
  return { verdict: "maybe", reason: "It can work if your hairline is even. The photo cannot prove that." };
}

export function buildLooks(profile: HairProfile, face: FaceRead): EngineLook[] {
  const own = PLACE[profile.length];
  const keep = profile.cut === "no" || profile.cut === "trim";
  const bestPlace = profile.cut === "suit" ? suitPlace(face.faceShape, profile.length) : profile.cut === "shorter" ? shorterPlace(profile.length) : own;
  const secondPlace = profile.cut === "shorter" ? shorterPlace(profile.length) : own;
  const lengthLine = (place: { end: string }) =>
    keep || place === own
      ? `The ends must sit ${place.end}. Do not cut it shorter than that.`
      : `The ends must sit ${place.end}. That length must be obvious.`;

  const faceWhy =
    face.faceShape === "unclear"
      ? "The face shape was not clear, so this stays close to your length and texture."
      : `A ${face.faceShape} face, ${profile.texture} hair, and your goal.`;

  return [
    {
      id: "s1",
      name: `${bestPlace.name} shape`,
      best: true,
      lengthPlan: profile.cut === "suit" ? "suit" : profile.cut === "shorter" ? "shorter" : profile.cut === "trim" ? "trim" : "keep",
      why: faceWhy,
      edit: `${lengthLine(bestPlace)} Shape the outline for a ${face.faceShape} face. ${profile.thickness === "fine" ? "Keep fullness. Do not thin it." : "Do not pile on bulk."} Keep the hairline. Do not add a fringe, curls, or waves.`,
    },
    {
      id: "s2",
      name: `${secondPlace.name} one-length`,
      best: false,
      lengthPlan: profile.cut === "shorter" ? "shorter" : profile.cut === "trim" ? "trim" : "keep",
      why: "One length. No layers. A different outline from the first look.",
      edit: `${lengthLine(secondPlace)} Cut it one length, blunt or softly rounded. Almost no layers. Keep the hairline. Do not add a fringe, curls, or waves.`,
    },
    {
      id: "s3",
      name: `${own.name} layers`,
      best: false,
      lengthPlan: profile.cut === "trim" ? "trim" : "keep",
      why: "A visible layer line. Not a softer version of the one-length cut.",
      edit: `${lengthLine(own)} Cut visible layers that start below the chin. The layer line must be obvious. Do not make it one length. Keep the hairline. Do not add a fringe, curls, or waves.`,
    },
    {
      id: "s4",
      name: `${own.name} crown volume`,
      best: false,
      lengthPlan: profile.cut === "trim" ? "trim" : "keep",
      why: "Volume at the crown. Same length. Not layers and not one length.",
      edit: `${lengthLine(own)} Lift the crown and keep the ends heavier. No layers through the bottom. Keep the hairline. Do not add a fringe, curls, or waves.`,
    },
  ];
}

export function carePlan(profile: HairProfile): { steps: string[]; doctor: string | null } {
  const steps = ["Wash the scalp, not the lengths, unless the lengths are oily."];
  if (profile.problems.includes("oily")) steps.push("Shampoo the roots. Do not scrub the ends.");
  if (profile.problems.includes("dry")) {
    steps.push("Use a conditioner on the lengths every wash.");
    steps.push("Use a mask once a week.");
    steps.push("Use a few drops of oil or serum on the ends only.");
  }
  if (profile.problems.includes("breakage") || profile.history.includes("bleach") || profile.history.includes("relaxer")) {
    steps.push("Stop bleaching and tight styles until the breakage slows.");
    steps.push("Trim the split ends. A box dye will not fix breakage.");
  }
  if (profile.problems.includes("thinning") || profile.problems.includes("slow") || profile.goal.includes("grow")) {
    steps.push("Do not pull the hair tight. Loose styles while you grow it.");
    steps.push("Be patient. Hair grows about 1 cm a month. No dye makes it grow faster.");
  }
  if (profile.heat === "daily" || profile.heat === "sometimes") {
    steps.push("Use a heat protectant before any hot tool, and turn the heat down.");
  }
  if (profile.time === "5" || profile.goal.includes("easy")) {
    steps.push("Pick a cut you can leave to dry. Skip a style that needs 30 minutes.");
  }
  if (previouslyColored(profile)) {
    steps.push("Wait at least a few weeks between colour. Do a patch test every time.");
  }
  if (profile.texture === "curly" || profile.texture === "coily") {
    steps.push("Detangle wet hair with conditioner. Do not brush it dry.");
  }
  const doctor =
    profile.problems.includes("thinning") || profile.problems.includes("itchy") || profile.problems.includes("slow")
      ? "If hair is falling out suddenly, or the scalp is sore, swollen, or weeping, see a doctor. This app cannot diagnose that."
      : null;
  return { steps, doctor };
}

export const PHOTO_TIPS = [
  { title: "Daylight", text: "Face a window. No direct sun. No yellow or coloured light." },
  { title: "Hair down", text: "Wear it loose. Not tied back, not clipped." },
  { title: "Eye level", text: "Camera at eye level, arm's length. Face in the centre. Shoulders in the frame." },
  { title: "No filters", text: "No beauty mode. Glasses off. Little or no makeup." },
  { title: "Eyes open", text: "A neutral expression. Eyes open. Look at the camera." },
] as const;
