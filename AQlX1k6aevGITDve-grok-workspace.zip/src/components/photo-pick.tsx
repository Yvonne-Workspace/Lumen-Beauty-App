import { Camera, ImagePlus } from "lucide-react";

export function PhotoPick({
  onFile,
  disabled,
  takeLabel = "Take a photo",
  chooseLabel = "Choose a photo",
}: {
  onFile: (file: File) => void;
  disabled?: boolean;
  takeLabel?: string;
  chooseLabel?: string;
}) {
  function onChange(event: React.ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    event.currentTarget.value = "";
    if (file) onFile(file);
  }

  const takeClass = disabled
    ? "btn btn-primary pointer-events-none min-h-14 w-full opacity-45 sm:w-auto"
    : "btn btn-primary relative min-h-14 w-full sm:w-auto";
  const chooseClass = disabled
    ? "btn btn-quiet pointer-events-none min-h-14 w-full opacity-45 sm:w-auto"
    : "btn btn-quiet relative min-h-14 w-full sm:w-auto";

  return (
    <div className="flex flex-wrap gap-2">
      <label className={takeClass}>
        <Camera className="size-4" aria-hidden="true" />
        {takeLabel}
        <input
          className="absolute inset-0 z-10 h-full w-full cursor-pointer opacity-[0.02]"
          style={{ fontSize: "16px" }}
          type="file"
          accept="image/*"
          capture="user"
          disabled={disabled}
          onChange={onChange}
        />
      </label>
      <label className={chooseClass}>
        <ImagePlus className="size-4" aria-hidden="true" />
        {chooseLabel}
        <input
          className="absolute inset-0 z-10 h-full w-full cursor-pointer opacity-[0.02]"
          style={{ fontSize: "16px" }}
          type="file"
          accept="image/*"
          disabled={disabled}
          onChange={onChange}
        />
      </label>
    </div>
  );
}
