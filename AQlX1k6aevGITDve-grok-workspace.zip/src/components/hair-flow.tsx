import { useEffect, useMemo, useRef, useState } from "react";
import { Check, Crown } from "lucide-react";
import {
  AGES,
  BUDGETS,
  CUTS,
  ENDS,
  EYES,
  GOALS,
  GREYS,
  HAIR_COLOURS,
  HEATS,
  HISTORIES,
  LASTS,
  LENGTHS,
  MOODS,
  PHOTO_TIPS,
  PIGMENTS,
  PROBLEMS,
  ROUTES,
  TEXTURES,
  THICKNESS,
  TIMES,
  YESNO,
  type HairProfile,
} from "@/lib/hair/engine";
import { PIXEL_TEXT, scanPixels, type PixelIssue } from "@/lib/hair/pixels";
import { checkedLabel, linkLabel, priceLabel, recheck } from "@/lib/hair/dye-database";
import { SWATCH_TARGET, matchHome, type HomeCard } from "@/lib/hair/dye-match";
import { explainThrown } from "@/lib/hair/studio-error";
import { fitPortrait } from "@/lib/portrait";
import {
  checkPortrait,
  previewLook,
  readPortrait,
  studioJob,
  type ColorOption,
  type PortraitReading,
  type StyleOption,
} from "@/lib/hair/studio.functions";

type Goal = HairProfile["goal"][number];
type History = HairProfile["history"][number];
type Problem = HairProfile["problems"][number];

type Draft = {
  goal: Goal[];
  age: HairProfile["age"] | null;
  eyes: HairProfile["eyes"] | null;
  length: HairProfile["length"] | null;
  cut: HairProfile["cut"] | null;
  thickness: HairProfile["thickness"] | null;
  texture: HairProfile["texture"] | null;
  natural: HairProfile["natural"] | null;
  current: HairProfile["current"] | null;
  grey: HairProfile["grey"] | null;
  pigment: HairProfile["pigment"] | null;
  history: History[];
  ends: HairProfile["ends"];
  last: HairProfile["last"] | null;
  problems: Problem[];
  heat: HairProfile["heat"] | null;
  time: HairProfile["time"] | null;
  route: HairProfile["route"] | null;
  budget: HairProfile["budget"] | null;
  mood: HairProfile["mood"] | null;
  curls: HairProfile["curls"] | null;
  fringe: HairProfile["fringe"] | null;
};

const EMPTY: Draft = {
  goal: [],
  age: null,
  eyes: null,
  length: null,
  cut: null,
  thickness: null,
  texture: null,
  natural: null,
  current: null,
  grey: null,
  pigment: null,
  history: [],
  ends: null,
  last: null,
  problems: [],
  heat: null,
  time: null,
  route: null,
  budget: null,
  mood: null,
  curls: null,
  fringe: null,
};

type StepId =
  | "goal"
  | "age"
  | "eyes"
  | "length"
  | "cut"
  | "thickness"
  | "texture"
  | "natural"
  | "current"
  | "grey"
  | "pigment"
  | "history"
  | "ends"
  | "last"
  | "problems"
  | "heat"
  | "time"
  | "route"
  | "budget"
  | "mood"
  | "curls"
  | "fringe";

const STEP_COPY: Record<StepId, { title: string; tip?: string; multi?: boolean }> = {
  goal: { title: "What do you want?", multi: true },
  age: { title: "How old are you?" },
  eyes: { title: "What colour are your eyes?", tip: "Undertone is the colour under your skin: warm, cool, or neutral. Eye colour is separate. It changes which brown looks right." },
  length: { title: "How long is your hair now?" },
  cut: { title: "Are you open to cutting it?" },
  thickness: { title: "How thick is your hair?" },
  texture: { title: "What is the texture?" },
  natural: { title: "What is your natural colour?" },
  current: { title: "What colour is it now?" },
  grey: { title: "How much grey is there?" },
  pigment: { title: "Is red or orange showing?", tip: "Red pigmentation means a brown dye later turns orange or red on you. Say yes, and those tones are left out." },
  history: {
    title: "What has been done to it?",
    multi: true,
    tip: "Balayage is colour painted by hand. Henna, keratin, and metal-based colour (such as a Grecian-type restorer) need a salon strand test. Do not use a box on those.",
  },
  ends: { title: "What colour are the ends?" },
  last: { title: "When was it last coloured?" },
  problems: { title: "Any hair or scalp problems?", multi: true },
  heat: { title: "Do you use heat?" },
  time: { title: "How long do you spend styling?" },
  route: { title: "Home box, or a salon?", tip: "A box dye cannot lighten hair that is already dyed. A big lift is salon only." },
  budget: { title: "What do you want to spend on a box?" },
  mood: { title: "Natural-looking, or bolder?" },
  curls: { title: "Want to see curls or waves?" },
  fringe: { title: "Want to see a fringe?" },
};

function stepsFor(draft: Draft): StepId[] {
  const steps: StepId[] = ["goal", "age", "eyes", "length", "cut", "thickness", "texture", "natural", "current", "grey", "pigment", "history"];
  if (draft.history.includes("balayage")) steps.push("ends");
  if (!(draft.history.length === 1 && draft.history[0] === "never")) steps.push("last");
  steps.push("problems", "heat", "time", "route");
  if (draft.route !== "salon") steps.push("budget");
  steps.push("mood", "curls", "fringe");
  return steps;
}

function profileFrom(draft: Draft): HairProfile | null {
  const neverOnly = draft.history.length === 1 && draft.history[0] === "never";
  const last = neverOnly ? "never" : draft.last;
  const budget = draft.route === "salon" ? (draft.budget ?? "mid") : draft.budget;
  const needsEnds = draft.history.includes("balayage");
  if (
    !draft.age ||
    !draft.eyes ||
    !draft.length ||
    !draft.cut ||
    !draft.thickness ||
    !draft.texture ||
    !draft.natural ||
    !draft.current ||
    !draft.grey ||
    !draft.pigment ||
    !last ||
    !budget ||
    !draft.heat ||
    !draft.time ||
    !draft.route ||
    !draft.mood ||
    !draft.curls ||
    !draft.fringe ||
    draft.goal.length === 0 ||
    draft.history.length === 0 ||
    (needsEnds && !draft.ends)
  ) {
    return null;
  }
  return {
    goal: draft.goal,
    age: draft.age,
    eyes: draft.eyes,
    length: draft.length,
    cut: draft.cut,
    thickness: draft.thickness,
    texture: draft.texture,
    natural: draft.natural,
    current: draft.current,
    grey: draft.grey,
    pigment: draft.pigment,
    history: draft.history,
    ends: needsEnds ? draft.ends : null,
    last,
    problems: draft.problems,
    heat: draft.heat,
    time: draft.time,
    route: draft.route,
    budget,
    mood: draft.mood,
    curls: draft.curls,
    fringe: draft.fringe,
  };
}

const VISION_TEXT = {
  faceSmall: "Your face is too small in the frame.",
  hairTied: "Your hair looks tied back. Wear it down.",
  glasses: "Take your glasses off.",
  filter: "This looks like a beauty filter. Take it again with filters off.",
} as const;

export function PhotoGuide() {
  return (
    <section className="panel p-4">
      <h2 className="text-sm font-medium text-ink">How to take your photo</h2>
      <ul className="mt-3 grid gap-2">
        {PHOTO_TIPS.map((item) => (
          <li key={item.title} className="flex gap-3 rounded-md border border-line px-3 py-2">
            <TipIcon name={item.title} />
            <span>
              <span className="block text-sm font-medium text-ink">{item.title}</span>
              <span className="block text-sm text-stone">{item.text}</span>
            </span>
          </li>
        ))}
      </ul>
    </section>
  );
}

export function HairFlow({
  portrait,
  onUse,
}: {
  portrait: string | null;
  onUse: (hair: { name: string; color: string; image: string }, age: HairProfile["age"]) => void;
}) {
  const [draft, setDraft] = useState<Draft>(EMPTY);
  const [step, setStep] = useState(0);
  const [pixelIssues, setPixelIssues] = useState<PixelIssue[]>([]);
  const [vision, setVision] = useState<string[]>([]);
  const [lightingOk, setLightingOk] = useState<boolean | null>(null);
  const [checked, setChecked] = useState<"pending" | "ask" | "go">("pending");
  const [reading, setReading] = useState<PortraitReading | null>(null);
  const [colorId, setColorId] = useState<string | null>(null);
  const [pickedId, setPickedId] = useState<string | null>(null);
  const [images, setImages] = useState<Record<string, string>>({});
  const [failed, setFailed] = useState<Record<string, string>>({});
  const [extras, setExtras] = useState<Record<string, string>>({});
  const [progress, setProgress] = useState<string | null>(null);
  const [busy, setBusy] = useState<"check" | "read" | "paint" | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [tip, setTip] = useState(false);

  const photoRef = useRef<string | null>(null);
  const steps = useMemo(() => stepsFor(draft), [draft]);
  const current = steps[Math.min(step, steps.length - 1)] ?? "goal";
  const color = reading?.colors.find((item) => item.id === colorId) ?? null;
  const picked = reading?.styles.find((item) => item.id === pickedId) ?? null;

  useEffect(() => {
    setChecked("pending");
    setReading(null);
    setImages({});
    setStep(0);
    setNotice(null);
  }, [portrait]);

  useEffect(() => {
    if (!portrait || checked !== "pending") return;
    let cancel = false;
    setBusy("check");
    void (async () => {
      try {
        const pixels = await scanPixels(portrait);
        if (cancel) return;
        setPixelIssues(pixels);
        const started = await checkPortrait({ data: { imageDataUrl: portrait } });
        const result = await waitFor(started.jobId);
        if (cancel) return;
        if (result.ok && "check" in result) {
          const lines = [
            result.check.faceSmall ? VISION_TEXT.faceSmall : "",
            result.check.hairTied ? VISION_TEXT.hairTied : "",
            result.check.glasses ? VISION_TEXT.glasses : "",
            result.check.filter ? VISION_TEXT.filter : "",
          ].filter(Boolean);
          setVision(lines);
          setLightingOk(result.check.lightingOk && !pixels.includes("dark") && !pixels.includes("yellow") && !pixels.includes("shadow"));
          if (!result.check.lightingOk && result.check.note) setNotice(result.check.note);
        } else {
          setLightingOk(!pixels.includes("dark") && !pixels.includes("yellow") && !pixels.includes("shadow"));
          if (!result.ok) setNotice("I could not fully check the photo. The light check below is from the picture itself.");
        }
      } catch {
        if (!cancel) setNotice("I could not check that photo. You can retake it.");
      } finally {
        if (!cancel) {
          setBusy(null);
          setChecked("ask");
        }
      }
    })();
    return () => {
      cancel = true;
    };
  }, [portrait, checked]);

  async function finish(next: Draft) {
    if (!portrait) return;
    const profile = profileFrom(next);
    if (!profile) {
      setNotice("Some answers are missing. Your other answers are still here.");
      return;
    }
    setDraft(next);
    setBusy("read");
    setNotice(null);
    try {
      const photo = await fitPortrait(portrait);
      photoRef.current = photo;
      const started = await readPortrait({ data: { imageDataUrl: photo, profile } });
      const result = await waitFor(started.jobId);
      if (!result.ok || !("reading" in result)) {
        setNotice("message" in result ? result.message : "The reading did not go through. Try again.");
        return;
      }
      setReading(result.reading);
      const best = result.reading.colors.find((item) => item.best) ?? result.reading.colors[0];
      setColorId(best?.id ?? null);
      const bestLook = result.reading.styles.find((item) => item.best) ?? result.reading.styles[0];
      setPickedId(bestLook?.id ?? null);
      if (best && result.reading.lightingOk) await paintAll(result.reading, best, photo, profile);
    } catch (error) {
      setNotice(explainThrown(error));
    } finally {
      setBusy(null);
    }
  }

  async function paintLook(photo: string, look: StyleOption, next: ColorOption, profile: HairProfile, styleEdit = look.edit, styleName = look.name) {
    let last = "A look did not paint.";
    for (let attempt = 0; attempt < 3; attempt += 1) {
      if (attempt > 0) await new Promise((resolve) => setTimeout(resolve, 1500));
      try {
        const started = await previewLook({
          data: {
            imageDataUrl: photo,
            styleName,
            styleEdit,
            colorName: next.name,
            colorEdit: next.edit,
            lengthPlan: look.lengthPlan,
            pigment: profile.pigment,
            grey: profile.grey,
          },
        });
        const result = await waitFor(started.jobId);
        if (result.ok && "imageUrl" in result) return { ok: true as const, imageUrl: result.imageUrl };
        last = "message" in result ? result.message : last;
      } catch (error) {
        last = explainThrown(error);
      }
      if (/credits|too large|adult/i.test(last)) break;
    }
    return { ok: false as const, message: last };
  }

  async function paintAll(source: PortraitReading, next: ColorOption, photo: string, profile: HairProfile) {
    setBusy("paint");
    setImages({});
    setFailed({});
    setExtras({});
    setNotice(null);
    const done: Record<string, string> = {};
    const missed: Record<string, string> = {};
    try {
      for (let index = 0; index < source.styles.length; index += 1) {
        const look = source.styles[index];
        if (!look) continue;
        setProgress(`Look ${index + 1} of ${source.styles.length}…`);
        const result = await paintLook(photo, look, next, profile);
        if (result.ok) done[look.id] = result.imageUrl;
        else missed[look.id] = result.message;
        setImages({ ...done });
        setFailed({ ...missed });
      }
      const messages = Object.values(missed);
      if (messages.length === source.styles.length && messages[0]) setNotice(messages[0]);
      else if (messages.length > 0) setNotice("Some looks did not paint. The ones that worked are still here.");
    } catch (error) {
      setNotice(explainThrown(error));
    } finally {
      setProgress(null);
      setBusy(null);
    }
  }

  async function retryLook(lookId: string) {
    if (!reading || !color || !portrait || busy) return;
    const profile = profileFrom(draft);
    const look = reading.styles.find((item) => item.id === lookId);
    if (!profile || !look) return;
    setBusy("paint");
    setProgress(`Look 1 of 1…`);
    setNotice(null);
    try {
      const photo = photoRef.current ?? (await fitPortrait(portrait));
      photoRef.current = photo;
      const result = await paintLook(photo, look, color, profile);
      if (result.ok) {
        setImages((currentImages) => ({ ...currentImages, [lookId]: result.imageUrl }));
        setFailed((currentFailed) => {
          const nextFailed = { ...currentFailed };
          delete nextFailed[lookId];
          return nextFailed;
        });
      } else {
        setFailed((currentFailed) => ({ ...currentFailed, [lookId]: result.message }));
        setNotice(result.message);
      }
    } catch (error) {
      setNotice(explainThrown(error));
    } finally {
      setProgress(null);
      setBusy(null);
    }
  }

  async function paintExtra(kind: "fringe" | "curls") {
    if (!reading || !color || !picked || !portrait || busy) return;
    const profile = profileFrom(draft);
    if (!profile) return;
    const styleName = kind === "fringe" ? "Fringe" : "Curls or waves";
    const styleEdit =
      kind === "fringe"
        ? `${picked.edit} Add a soft fringe that ends just above the brows. Keep this cut and this length.`
        : `${picked.edit} Add loose waves through the lengths. Not a tight perm. Keep this cut and this length.`;
    setBusy("paint");
    setProgress(kind === "fringe" ? "Making the fringe…" : "Making the curls…");
    setNotice(null);
    try {
      const photo = photoRef.current ?? (await fitPortrait(portrait));
      photoRef.current = photo;
      const result = await paintLook(photo, picked, color, profile, styleEdit.slice(0, 500), styleName);
      if (result.ok) setExtras((currentExtras) => ({ ...currentExtras, [`${picked.id}-${kind}`]: result.imageUrl }));
      else setNotice(result.message);
    } catch (error) {
      setNotice(explainThrown(error));
    } finally {
      setProgress(null);
      setBusy(null);
    }
  }

  function advance(next: Draft) {
    const list = stepsFor(next);
    const following = step + 1;
    if (following >= list.length) {
      setDraft(next);
      void finish(next);
      return;
    }
    setDraft(next);
    setStep(following);
    setTip(false);
  }

  if (!portrait) return null;

  const problems = [...pixelIssues.map((item) => PIXEL_TEXT[item]), ...vision];
  const blockedLight = lightingOk === false;

  return (
    <div className="grid gap-6">
      {busy ? <Working mode={busy} detail={progress} /> : null}
      {checked === "ask" && !reading ? (
        <section className="panel p-4">
          <h2 className="text-sm font-medium text-ink">Photo check</h2>
          {problems.length > 0 ? (
            <ul className="mt-3 grid gap-2">
              {problems.map((item) => (
                <li key={item} className="note">
                  {item}
                </li>
              ))}
            </ul>
          ) : (
            <p className="mt-2 text-sm text-stone">The light and the frame look usable.</p>
          )}
          {blockedLight ? (
            <p className="mt-3 text-sm text-ink">Retake the photo. I will not guess a colour from this light.</p>
          ) : (
            <div className="mt-3 flex flex-wrap gap-2">
              <button
                type="button"
                className="btn btn-primary"
                onClick={() => {
                  const ready = profileFrom(draft);
                  if (ready) void finish(draft);
                  else setChecked("go");
                }}
              >
                {profileFrom(draft) ? "Use these answers" : problems.length > 0 ? "Use anyway" : "Continue"}
              </button>
              {profileFrom(draft) ? (
                <button type="button" className="btn btn-quiet" onClick={() => { setStep(0); setChecked("go"); }}>
                  Answer again
                </button>
              ) : null}
            </div>
          )}
          <p className="mt-2 text-xs text-mist">To retake, use Take a photo or Choose a photo above.</p>
        </section>
      ) : null}

      {checked === "go" && !reading && !(profileFrom(draft) && notice) ? (
        <Question
          index={step}
          total={steps.length}
          id={current}
          draft={draft}
          tipOpen={tip}
          onTip={() => setTip((value) => !value)}
          onBack={() => {
            setTip(false);
            setStep((value) => Math.max(0, value - 1));
          }}
          onDraft={(next) => {
            setDraft(next);
            setTip(false);
          }}
          onAdvance={advance}
        />
      ) : null}

      {notice && !(checked === "go" && !reading && profileFrom(draft)) ? <p className="note">{notice}</p> : null}

      {checked === "go" && !reading && profileFrom(draft) && notice ? (
        <section className="panel p-4">
          <p className="note">{notice}</p>
          <button type="button" className="btn btn-primary mt-3" onClick={() => void finish(draft)}>
            Try again
          </button>
          <p className="mt-2 text-sm text-stone">Your answers are still here. You do not need to start the questions again.</p>
        </section>
      ) : null}

      {reading ? (
        <Results
          reading={reading}
          images={images}
          color={color}
          profile={profileFrom(draft)}
          pickedId={pickedId}
          failed={failed}
          extras={extras}
          painting={busy === "paint"}
          route={draft.route}
          onPickLook={setPickedId}
          onRetry={(id) => void retryLook(id)}
          onExtra={(kind) => void paintExtra(kind)}
          onPickColor={(next) => {
            if (!portrait || busy) return;
            const profile = profileFrom(draft);
            if (!profile || !reading.lightingOk) return;
            setColorId(next.id);
            const photo = photoRef.current ?? portrait;
            void paintAll(reading, next, photo, profile);
          }}
          onUse={() => {
            if (!picked || !color || !draft.age) return;
            const image = images[picked.id];
            if (!image) return;
            onUse({ name: picked.name, color: color.name, image }, draft.age);
          }}
        />
      ) : null}
    </div>
  );
}

function Question({
  index,
  total,
  id,
  draft,
  tipOpen,
  onTip,
  onBack,
  onDraft,
  onAdvance,
}: {
  index: number;
  total: number;
  id: StepId;
  draft: Draft;
  tipOpen: boolean;
  onTip: () => void;
  onBack: () => void;
  onDraft: (next: Draft) => void;
  onAdvance: (next: Draft) => void;
}) {
  const copy = STEP_COPY[id];
  const options = optionsFor(id);
  const selected = selectedFor(id, draft);
  return (
    <section className="panel p-4">
      <div className="progress-track">
        <div className="progress-fill" style={{ width: `${((index + 1) / total) * 100}%` }} />
      </div>
      <p className="mt-3 text-xs text-mist">
        {index + 1} of {total}
      </p>
      <div className="mt-1 flex items-start justify-between gap-3">
        <h2 className="text-xl font-medium text-ink">{copy.title}</h2>
        {copy.tip ? (
          <button type="button" className="btn btn-quiet min-h-11 px-3" aria-expanded={tipOpen} onClick={onTip}>
            ?
          </button>
        ) : null}
      </div>
      {tipOpen && copy.tip ? <p className="note mt-2">{copy.tip}</p> : null}
      <div className="mt-4 grid gap-2">
        {options.map((item) => {
          const on = Array.isArray(selected) ? selected.includes(item.id) : selected === item.id;
          return (
            <button
              key={item.id}
              type="button"
              className="choice min-h-14 text-base"
              aria-pressed={on}
              onClick={() => {
                const next = applyAnswer(id, draft, item.id, !copy.multi);
                if (copy.multi) onDraft(next);
                else onAdvance(next);
              }}
            >
              <span className="block font-medium text-ink">{item.label}</span>
              {"tip" in item && item.tip ? <span className="mt-1 block text-sm text-stone">{item.tip}</span> : null}
            </button>
          );
        })}
      </div>
      {copy.multi ? (
        <p className="mt-2 text-xs text-mist">
          {id === "problems" ? "Tap every one that applies. If none, tap Continue." : "Tap every one that applies, then Continue."}
        </p>
      ) : null}
      <div className="mt-4 flex flex-wrap gap-2">
        <button type="button" className="btn btn-quiet" disabled={index === 0} onClick={onBack}>
          Back
        </button>
        {copy.multi ? (
          <button
            type="button"
            className="btn btn-primary"
            disabled={id !== "problems" && selectedFor(id, draft).length === 0}
            onClick={() => onAdvance(draft)}
          >
            Continue
          </button>
        ) : null}
      </div>
    </section>
  );
}

function optionsFor(id: StepId) {
  if (id === "goal") return GOALS;
  if (id === "age") return AGES;
  if (id === "eyes") return EYES;
  if (id === "length") return LENGTHS;
  if (id === "cut") return CUTS;
  if (id === "thickness") return THICKNESS;
  if (id === "texture") return TEXTURES;
  if (id === "natural" || id === "current") return HAIR_COLOURS;
  if (id === "grey") return GREYS;
  if (id === "pigment") return PIGMENTS;
  if (id === "history") return HISTORIES;
  if (id === "ends") return ENDS;
  if (id === "last") return LASTS.filter((item) => item.id !== "never");
  if (id === "problems") return PROBLEMS;
  if (id === "heat") return HEATS;
  if (id === "time") return TIMES;
  if (id === "route") return ROUTES;
  if (id === "budget") return BUDGETS;
  if (id === "mood") return MOODS;
  return YESNO;
}

function selectedFor(id: StepId, draft: Draft): string | string[] {
  if (id === "goal") return draft.goal;
  if (id === "history") return draft.history;
  if (id === "problems") return draft.problems;
  const value = draft[id];
  return typeof value === "string" ? value : "";
}

function applyAnswer(id: StepId, draft: Draft, value: string, single: boolean): Draft {
  if (single) return { ...draft, [id]: value };
  if (id === "goal") {
    const goal = toggle(draft.goal, value as Goal);
    return { ...draft, goal };
  }
  if (id === "problems") return { ...draft, problems: toggle(draft.problems, value as Problem) };
  let history = toggle(draft.history, value as History);
  if (value === "never") history = history.includes("never") ? ["never"] : history;
  else history = history.filter((item) => item !== "never");
  return { ...draft, history, ends: history.includes("balayage") ? draft.ends : null };
}

function toggle<T extends string>(list: T[], value: T) {
  return list.includes(value) ? list.filter((item) => item !== value) : [...list, value];
}

function Results({
  reading,
  images,
  failed,
  extras,
  color,
  profile,
  pickedId,
  painting,
  route,
  onPickLook,
  onPickColor,
  onRetry,
  onExtra,
  onUse,
}: {
  reading: PortraitReading;
  images: Record<string, string>;
  failed: Record<string, string>;
  extras: Record<string, string>;
  color: ColorOption | null;
  profile: HairProfile | null;
  pickedId: string | null;
  painting: boolean;
  route: HairProfile["route"] | null;
  onPickLook: (id: string) => void;
  onPickColor: (color: ColorOption) => void;
  onRetry: (id: string) => void;
  onExtra: (kind: "fringe" | "curls") => void;
  onUse: () => void;
}) {
  const picked = reading.styles.find((item) => item.id === pickedId) ?? null;
  const home = profile && color ? matchHome(profile, color.id) : null;
  const target = color ? SWATCH_TARGET[color.id] : null;
  return (
    <div className="grid gap-5">
      <section>
        <h2 className="wordmark text-3xl text-ink">Your four looks</h2>
        <p className="mt-2 text-sm text-stone">{reading.summary}</p>
        {!reading.lightingOk ? <p className="note mt-3">{reading.lightingNote} I have not chosen colours.</p> : null}
        <div className="mt-4 grid grid-cols-2 gap-2">
          {reading.styles.map((look) => {
            const image = images[look.id];
            const problem = failed[look.id];
            const on = look.id === pickedId;
            return (
              <div key={look.id} className={on ? "choice border-char" : "choice"}>
                <button type="button" className="w-full text-left" aria-pressed={on} onClick={() => onPickLook(look.id)}>
                  <span className={image ? "relative block" : "shimmer relative block"}>
                    {image ? <img src={image} alt={look.name} className="aspect-[3/4] w-full rounded-sm object-cover" /> : <span className="block aspect-[3/4] rounded-sm bg-wash" />}
                    {on ? (
                      <span className="absolute top-2 right-2 grid size-7 place-items-center rounded-full bg-char text-char-fg">
                        <Check className="size-4" aria-hidden="true" />
                      </span>
                    ) : null}
                  </span>
                  <span className="mt-2 flex items-center gap-1 text-sm font-medium text-ink">
                    {look.best ? <Crown className="size-4" aria-hidden="true" /> : null}
                    {look.name}
                  </span>
                  {look.best ? <span className="mt-1 block text-xs text-stone">Best match for you. {look.why}</span> : <span className="mt-1 block text-xs text-stone">{look.why}</span>}
                  {problem && !image ? <span className="mt-1 block text-xs text-ink">{problem}</span> : null}
                </button>
                {problem && !image ? (
                  <button type="button" className="btn btn-quiet mt-2" disabled={painting} onClick={() => onRetry(look.id)}>
                    Retry this look
                  </button>
                ) : null}
              </div>
            );
          })}
        </div>
      </section>

      {reading.colors.length > 0 ? (
        <section>
          <h3 className="text-sm font-medium text-ink">Colours</h3>
          {reading.colorNote ? <p className="mt-1 text-sm text-stone">{reading.colorNote}</p> : null}
          <p className="mt-1 text-xs text-mist">
            Skin {reading.skinDepth}, undertone {reading.undertone}. Tap a colour to put it on all four looks.
          </p>
          <div className="mt-3 flex gap-2 overflow-x-auto pb-1">
            {reading.colors.map((item) => (
              <button
                key={item.id}
                type="button"
                className={item.id === color?.id ? "min-w-28 shrink-0 rounded-md border-2 border-char p-2 text-left" : "min-w-28 shrink-0 rounded-md border border-line p-2 text-left"}
                aria-pressed={item.id === color?.id}
                onClick={() => onPickColor(item)}
              >
                <span className="block h-8 rounded-sm border border-line" style={{ background: item.hex }} />
                <span className="mt-1 block text-xs font-medium text-ink">{item.name}</span>
                {SWATCH_TARGET[item.id] ? (
                  <span className="block text-xs text-stone">
                    Level {SWATCH_TARGET[item.id]?.level} · {SWATCH_TARGET[item.id]?.tone}
                  </span>
                ) : null}
                {item.best ? <span className="block text-xs text-stone">Best colour for you</span> : null}
                {item.salonOnly ? <span className="block text-xs text-stone">Salon only</span> : null}
              </button>
            ))}
          </div>
          {painting ? <p className="mt-2 text-sm text-stone">Putting this colour on all four looks…</p> : null}
        </section>
      ) : null}

      <section className="grid gap-2 sm:grid-cols-2">
        <article className="note">
          <p className="text-xs text-mist">Curls or waves</p>
          <p className="mt-1 text-sm font-medium text-ink">{labelVerdict(reading.curls.verdict)}</p>
          <p className="mt-1 text-sm text-stone">{reading.curls.reason}</p>
        </article>
        <article className="note">
          <p className="text-xs text-mist">Fringe</p>
          <p className="mt-1 text-sm font-medium text-ink">{labelVerdict(reading.fringe.verdict)}</p>
          <p className="mt-1 text-sm text-stone">{reading.fringe.reason}</p>
        </article>
      </section>

      {profile && color && picked ? (
        <section className="grid gap-3">
          <h3 className="text-sm font-medium text-ink">Optional previews</h3>
          <p className="text-sm text-stone">These are separate from the four looks. They do not replace a cut.</p>
          {profile.curls === "yes" && reading.curls.verdict !== "no" ? (
            <div>
              <button type="button" className="btn btn-quiet" disabled={painting} onClick={() => onExtra("curls")}>
                See curls or waves on {picked.name}
              </button>
              {extras[`${picked.id}-curls`] ? <img src={extras[`${picked.id}-curls`]} alt="" className="mt-2 aspect-[3/4] w-40 rounded-sm object-cover" /> : null}
            </div>
          ) : null}
          {profile.fringe === "yes" && reading.fringe.verdict !== "no" ? (
            <div>
              <button type="button" className="btn btn-quiet" disabled={painting} onClick={() => onExtra("fringe")}>
                See a fringe on {picked.name}
              </button>
              {extras[`${picked.id}-fringe`] ? <img src={extras[`${picked.id}-fringe`]} alt="" className="mt-2 aspect-[3/4] w-40 rounded-sm object-cover" /> : null}
            </div>
          ) : null}
        </section>
      ) : null}

      {color && reading.lightingOk && profile ? (
        <>
          {route === "salon" || home?.blocked || home?.salonOnly || home?.empty ? (
            <SalonCard look={picked} color={color} image={picked ? images[picked.id] : undefined} level={target?.level} tone={target?.tone} />
          ) : null}
          {route !== "salon" && home ? <HomeShelf key={color.id} match={home} boxBefore={profile.history.includes("box")} /> : null}
        </>
      ) : null}

      <section>
        <h3 className="text-sm font-medium text-ink">Hair care</h3>
        <ul className="mt-2 grid gap-2">
          {reading.care.map((item) => (
            <li key={item} className="text-sm text-stone">
              {item}
            </li>
          ))}
        </ul>
        {reading.doctor ? <p className="note mt-3">{reading.doctor}</p> : null}
      </section>

      <button type="button" className="btn btn-primary" disabled={!picked || !color || !images[picked.id]} onClick={onUse}>
        Use this look
      </button>
      <p className="text-xs text-mist">
        The edit is meant for the hair only. This tool cannot keep every original pixel of your face, skin, and background. If the face changes, retake and try again.
      </p>
    </div>
  );
}

function HomeShelf({ match, boxBefore }: { match: ReturnType<typeof matchHome>; boxBefore: boolean }) {
  const [ready, setReady] = useState(false);
  const [picked, setPicked] = useState(match.cards[0]?.dye.id ?? "");
  const [saved, setSaved] = useState(false);
  useEffect(() => {
    const timer = window.setTimeout(() => setReady(true), 350);
    return () => window.clearTimeout(timer);
  }, []);
  const chosen = match.cards.find((card) => card.dye.id === picked) ?? match.cards[0] ?? null;
  return (
    <section className="grid gap-3">
      <h3 className="text-sm font-medium text-ink">At home</h3>
      <p className="text-sm text-stone">Results depend on your current hair colour and lighting.</p>
      {match.blocked ? <p className="note">{match.blocked}</p> : null}
      {match.salonOnly ? <p className="note">{match.salonOnly}</p> : null}
      {match.empty ? <p className="note">{match.empty}</p> : null}
      {!ready ? (
        <div className="shimmer h-28 rounded-md bg-wash" />
      ) : (
        <div className="grid gap-2">
          {match.cards.map((card) => (
            <DyeCard key={card.dye.id} card={card} pressed={card.dye.id === chosen?.dye.id} onPick={() => { setPicked(card.dye.id); setSaved(false); }} />
          ))}
        </div>
      )}
      <details className="note">
        <summary className="cursor-pointer font-medium text-ink">How to apply</summary>
        <ul className="mt-2 grid gap-1 text-sm text-stone">
          <li>Patch test 48 hours before every colour.</li>
          <li>Wear gloves.</li>
          <li>Roots first. If you are refreshing, put colour on the lengths only for the last few minutes.</li>
          <li>Follow the time on the box.</li>
          <li>Rinse until the water runs clear.</li>
          <li>Use a colour-safe conditioner.</li>
        </ul>
        {boxBefore ? <p className="mt-2 text-sm text-ink">You have used box dye before. Do the roots, then the lengths only at the end, so the ends do not build up darker.</p> : null}
      </details>
      {chosen ? (
        <div>
          <button type="button" className="btn btn-primary" onClick={() => setSaved(true)}>
            Save my list
          </button>
          {saved ? (
            <div className="note mt-2">
              <p className="text-sm font-medium text-ink">
                {chosen.dye.brand} {chosen.dye.range} {chosen.dye.shadeName} {chosen.dye.shadeNo}
              </p>
              <p className="mt-1 text-sm text-stone">
                {chosen.dye.store} · {priceLabel(chosen.dye.price)}
              </p>
              <p className="mt-1 text-sm text-ink">Total: {priceLabel(chosen.dye.price)}</p>
              <p className="mt-1 text-sm text-stone">Check stock in store or online. Prices were seen in a listing and can change.</p>
            </div>
          ) : null}
        </div>
      ) : null}
    </section>
  );
}

function DyeCard({ card, pressed, onPick }: { card: HomeCard; pressed: boolean; onPick: () => void }) {
  const item = card.dye;
  const confirm = item.shadeNo.toLowerCase().includes("confirm");
  return (
    <article className={pressed ? "note border-char" : "note"}>
      <button type="button" className="w-full text-left" aria-pressed={pressed} onClick={onPick}>
        <p className="text-xs text-mist">{card.role}</p>
        <p className="mt-1 text-sm font-medium text-ink">
          {item.brand} · {item.range}
        </p>
        <p className="text-sm text-ink">
          {item.shadeName}
          {confirm ? "" : ` ${item.shadeNo}`}
        </p>
        <p className="mt-2 flex flex-wrap gap-2 text-xs text-stone">
          <span className="rounded-full border border-line px-2 py-1">{item.tone}</span>
          <span className="rounded-full border border-line px-2 py-1">{item.level == null ? "Confirm level" : `Level ${item.level}`}</span>
        </p>
        <p className="mt-2 text-sm text-stone">
          {priceLabel(item.price)} · {item.store}
        </p>
        <p className="mt-1 text-xs text-mist">Price last checked: {checkedLabel(item.lastChecked)}</p>
        {recheck(item.lastChecked) ? <p className="mt-1 text-xs text-ink">Price may have changed.</p> : null}
        {confirm ? <p className="mt-1 text-xs text-ink">Confirm the shade number on the box.</p> : null}
        {item.type === "Semi-permanent" ? <p className="mt-1 text-xs text-stone">Gentler, lower damage. It does not lift hair.</p> : null}
        {card.salonRecommended && card.salonReason ? <p className="mt-1 text-xs text-ink">Salon recommended. {card.salonReason}</p> : null}
      </button>
      <a className="mt-2 inline-block text-sm font-medium text-ink underline" href={item.url} target="_blank" rel="noreferrer">
        {linkLabel(item)}
      </a>
    </article>
  );
}

function SalonCard({
  look,
  color,
  image,
  level,
  tone,
}: {
  look: { name: string } | null;
  color: ColorOption;
  image?: string;
  level?: number;
  tone?: string;
}) {
  return (
    <article className="note">
      <p className="text-xs text-mist">Show your hairdresser</p>
      {image ? <img src={image} alt="" className="mt-2 aspect-[3/4] w-40 rounded-sm object-cover" /> : null}
      <p className="mt-2 text-sm text-ink">
        Cut: {look?.name ?? "the shape in the picture"}.
        {level && tone ? ` Colour to ask for: level ${level}, ${tone}.` : ""} {color.why}
      </p>
      <p className="mt-2 text-sm text-stone">Ask them to do this colour and this shape. You do not need to buy the box unless they tell you to.</p>
      {color.salonOnly ? <p className="mt-2 text-sm text-stone">A box dye cannot do this lift safely.</p> : null}
    </article>
  );
}

function labelVerdict(value: "yes" | "maybe" | "no") {
  if (value === "yes") return "Yes";
  if (value === "maybe") return "Maybe";
  return "No";
}

function Working({ mode, detail }: { mode: "check" | "read" | "paint"; detail?: string | null }) {
  const lines = mode === "paint" ? ["Styling your hair…", "Putting the colour on…"] : mode === "read" ? ["Reading your face…", "Choosing your colours…"] : ["Checking the photo…"];
  const [index, setIndex] = useState(0);
  useEffect(() => {
    const timer = window.setInterval(() => setIndex((value) => (value + 1) % lines.length), 1600);
    return () => window.clearInterval(timer);
  }, [lines.length]);
  return (
    <div className="fixed inset-0 z-40 grid place-items-center bg-paper/85 px-6">
      <p className="wordmark text-3xl text-ink">{detail || lines[index]}</p>
    </div>
  );
}

function TipIcon({ name }: { name: string }) {
  const common = { width: 28, height: 28, viewBox: "0 0 28 28", fill: "none", stroke: "#1a1816", strokeWidth: 1.6, "aria-hidden": true } as const;
  if (name === "Daylight") {
    return (
      <svg {...common}>
        <circle cx="14" cy="14" r="4" />
        <path d="M14 4v3M14 21v3M4 14h3M21 14h3M6.5 6.5l2 2M19.5 19.5l2 2M21.5 6.5l-2 2M8.5 19.5l-2 2" />
      </svg>
    );
  }
  if (name === "Hair down") {
    return (
      <svg {...common}>
        <circle cx="14" cy="9" r="3" />
        <path d="M9 13c0 6 2 11 5 11s5-5 5-11" />
      </svg>
    );
  }
  if (name === "Eye level") {
    return (
      <svg {...common}>
        <rect x="6" y="7" width="16" height="12" rx="2" />
        <circle cx="14" cy="13" r="2" />
      </svg>
    );
  }
  if (name === "No filters") {
    return (
      <svg {...common}>
        <circle cx="14" cy="12" r="4" />
        <path d="M8 22c1.5-3 3.5-4 6-4s4.5 1 6 4" />
      </svg>
    );
  }
  return (
    <svg {...common}>
      <circle cx="10" cy="12" r="1" fill="#1a1816" />
      <circle cx="18" cy="12" r="1" fill="#1a1816" />
      <path d="M10 18h8" />
    </svg>
  );
}

async function waitFor(jobId: string) {
  for (let attempt = 0; attempt < 45; attempt += 1) {
    const step = await studioJob({ data: { jobId } });
    if (!step.pending) return step.result;
    await new Promise((resolve) => setTimeout(resolve, 2000));
  }
  return { ok: false as const, message: "That is still running. Stay on this page and try once more." };
}
