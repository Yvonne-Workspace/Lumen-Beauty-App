import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const MAX_IMAGE = 2_800_000;

const imageField = z
  .string()
  .min(32)
  .max(MAX_IMAGE)
  .refine((value) => /^data:image\/(jpeg|png|webp);base64,/.test(value), {
    message: "Upload a JPEG, PNG, or WebP photo.",
  });

const zoneId = z.enum(["skin", "under", "cheek", "brow", "lid", "crease", "liner", "lip"]);
const concernId = z.enum(["hooded", "circles", "lines", "redness", "brows", "lips"]);

const aimId = z.enum(["natural", "polished", "work", "daytime", "evening", "goingout"]);

const readInput = z.object({
  imageDataUrl: imageField,
  age: z.enum(["under30", "thirties", "forties", "fifties", "sixty"]),
  aims: z.array(aimId).min(1).max(6),
  concerns: z.array(concernId).max(6),
});

const paintInput = z.object({
  imageDataUrl: imageField,
  edit: z.string().trim().min(1).max(700),
  eyeShape: z.string().trim().max(40),
  underEye: z.string().trim().max(40),
  age: z.enum(["under30", "thirties", "forties", "fifties", "sixty"]),
  aim: aimId,
  keepHair: z.boolean(),
});

export type MakeupStep = {
  zone: z.infer<typeof zoneId>;
  title: string;
  where: string;
  how: string;
  tool: string;
};

export type MakeupLook = {
  id: z.infer<typeof aimId>;
  name: string;
  why: string;
  edit: string;
  lesson: string;
};

export type MakeupReading = {
  eyeShape: string;
  underEye: string;
  skin: string;
  brows: string;
  lips: string;
  summary: string;
  steps: MakeupStep[];
  looks: MakeupLook[];
  avoid: string[];
};

export type MakeupReadResult = { ok: true; reading: MakeupReading } | { ok: false; message: string };
export type MakeupPaintResult = { ok: true; imageUrl: string } | { ok: false; message: string };

const AGE_LABEL = {
  under30: "under 30",
  thirties: "in her 30s",
  forties: "in her 40s",
  fifties: "in her 50s",
  sixty: "60 or older",
} as const;

const AIM_LABEL = {
  natural: "natural, with color you can still see",
  polished: "polished, a complete face that is obviously made up",
  work: "right for work, neat and clearly finished",
  daytime: "daytime, fresh and visibly made up",
  evening: "evening, stronger eyes and lip",
  goingout: "going out, the fullest of the looks",
} as const;

const AIM_NAME = {
  natural: "Natural",
  polished: "Polished",
  work: "For work",
  daytime: "Daytime",
  evening: "Evening",
  goingout: "Going out",
} as const;

const CONCERN_LABEL = {
  hooded: "hooded eyes",
  circles: "circles or darkness under the eyes",
  lines: "fine lines",
  redness: "redness",
  brows: "sparse brows",
  lips: "thin lips or lip lines",
} as const;

function readingPrompt(facts: z.infer<typeof readInput>) {
  const concerns = facts.concerns.length
    ? facts.concerns.map((item) => CONCERN_LABEL[item]).join(", ")
    : "nothing she already named";
  const wants = facts.aims.map((item) => `${item} = ${AIM_LABEL[item]}`).join("; ");
  const mature = facts.age === "forties" || facts.age === "fifties" || facts.age === "sixty";
  return `Look at this woman's face. This is a makeup reading, not a medical diagnosis.
She is ${AGE_LABEL[facts.age]}. She may want more than one finish: ${wants}.
She says she has: ${concerns}. Trust that over a guess when they disagree.
Scan the photo itself. Name what is actually there: the eye shape with the eyes open, whether the lid is hooded or the crease is hidden, darkness or hollows under the eyes, redness, texture, brow density, and the lip line.
If there is no clearly visible adult face, return {"blocked":true,"reason":"noface"}.
If the person appears to be under 18, return {"blocked":true,"reason":"minor"}.
Otherwise return only this JSON:
{
  "blocked": false,
  "eyeShape": "hooded | almond | round | monolid | deep-set | downturned | upturned",
  "underEye": "clear | circles | hollow | lines | puffiness",
  "skin": "one sentence of what you see",
  "brows": "one sentence",
  "lips": "one sentence",
  "summary": "two sentences. The first is the most important thing to do for this face. The second says how the makeup should read.",
  "steps": [7 objects],
  "looks": [${facts.aims.length} objects],
  "avoid": ["short phrase", "short phrase"]
}
Each step: {"zone":"skin | under | cheek | brow | lid | crease | liner | lip","title":"at most four words","where":"exactly where it goes on THIS face, one sentence","how":"two sentences she can follow in a mirror. Say the motion. For the lid and the crease, say if the eye is open or closed, which third of the lid, and which way to blend.","tool":"the formula, not a brand."}
Order the steps as she should apply them. This is the how-to, not a label.
If the eyes are hooded, the lid color stays on the lid she can see with her eyes open, and the depth sits just above the fold and on the outer corner so it shows.
If there are circles, use a warm or yellow-toned concealer patted only on the darkness. Do not leave a grey or purple shadow, and do not paint a white half-moon.
${
  mature
    ? `She is mature. Follow Jackie Alves' over-50 method in the steps and in every look. Cream or satin base with a warm undertone if she is red, spotted on where the skin needs it, not a thick mask and not a white powdery base. Powder only on the T-zone and the eyelid. Leave the under-eye and the mouth area luminous so powder does not sit in lines. Blush in pink, peach, or coral, lifted on the cheek. No mauve, merlot, or purple. Light color through the lid, then a reddish-brown depth on the outer corner, fluffed up and slightly outward so the eye looks longer and more open. Inner corner stays light. A little shimmer only on the inner corner, never on a crepey under-eye. Brown liner, not a black ring around the eye. On the lower lashes, brown only halfway or three quarters of the way. A small brown triangle at the outer corner, not a long black wing. Mascara from the root so the lashes show. Lip liner to give the lip an edge, pink or rosewood rather than a brown lip, then color with a little shine, not a dry matte.`
    : "If she is younger, the makeup can be fresher, but it still has to be visible. Not a costume, and not a bare face."
}
Return one look for each finish she chose, in this order, with these exact ids: ${facts.aims.join(", ")}.
Each look: {"id":"one of those ids","name":"short name","why":"one sentence","lesson":"four sentences that teach the eyes for this finish, in order: the light shade, the outer-corner depth, the liner, then the mascara. Say open or closed, and the blend. This is the how-to.","edit":"40 to 70 words a photo editor can apply"}.
Every edit must describe makeup a person can see in a photo: color on the lid, a darker outer corner, blush on the cheek, lip color, and mascara. Polished, work, and daytime are a complete made-up face. They are not a bare face and not a no-makeup look. Natural is softer but still has a visible blush, a soft lid color, and a lip tint. Evening and going out are stronger.
Do not change her age, hair, or identity. No preamble, no markdown.`;
}

const UNAVAILABLE = "The makeup reading is unavailable right now. Try again in a moment.";

function clip(value: unknown, max: number): string {
  if (typeof value !== "string") return "";
  return value.replace(/\s+/g, " ").trim().slice(0, max);
}

function asRecord(value: unknown): Record<string, unknown> | null {
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  return value as Record<string, unknown>;
}

function errorDetail(json: unknown, status: number): string {
  const record = asRecord(json);
  const err = record ? asRecord(record.error) : null;
  const message = clip(err?.message ?? record?.message, 180);
  if (/minor|under 18|child/i.test(message)) return "Lumen only reads adult portraits.";
  if (status === 0) return message || UNAVAILABLE;
  return "The makeup reading could not finish. Try again.";
}

async function postXai(
  path: string,
  body: unknown,
): Promise<{ ok: true; json: unknown } | { ok: false; status: number; message: string }> {
  const apiKey = process.env.XAI_API_KEY;
  if (!apiKey) return { ok: false, status: 0, message: UNAVAILABLE };
  let response: Response;
  try {
    response = await fetch(`https://api.x.ai/v1${path}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(90_000),
    });
  } catch {
    return { ok: false, status: 0, message: "The makeup reading timed out. Try once more." };
  }
  const text = await response.text();
  let json: unknown = null;
  try {
    json = text ? JSON.parse(text) : null;
  } catch {
    json = null;
  }
  if (!response.ok) return { ok: false, status: response.status, message: errorDetail(json, response.status) };
  return { ok: true, json };
}

function messageText(json: unknown): string {
  const record = asRecord(json);
  const choices = record?.choices;
  if (!Array.isArray(choices) || !choices[0]) return "";
  const message = asRecord(choices[0])?.message;
  const content = asRecord(message)?.content;
  if (typeof content === "string") return content;
  if (!Array.isArray(content)) return "";
  return content
    .map((part) => {
      const row = asRecord(part);
      return typeof row?.text === "string" ? row.text : "";
    })
    .join("");
}

function parseJson(raw: string): Record<string, unknown> | null {
  const start = raw.indexOf("{");
  const end = raw.lastIndexOf("}");
  if (start < 0 || end <= start) return null;
  try {
    const value = JSON.parse(raw.slice(start, end + 1)) as unknown;
    return asRecord(value);
  } catch {
    return null;
  }
}

const ZONES = ["skin", "under", "cheek", "brow", "lid", "crease", "liner", "lip"] as const;

function parseReading(raw: string, aims: z.infer<typeof aimId>[]): MakeupReadResult {
  const data = parseJson(raw);
  if (!data) return { ok: false, message: "The reading came back in a form Lumen could not use. Try again." };
  if (data.blocked === true) {
    const reason = clip(data.reason, 40);
    if (reason === "minor") return { ok: false, message: "Lumen only reads adult portraits. Upload a photo of an adult." };
    return { ok: false, message: "Lumen needs a clear photo of one adult face." };
  }
  const steps = Array.isArray(data.steps)
    ? data.steps
        .map((item) => {
          const row = asRecord(item);
          const zone = clip(row?.zone, 16);
          if (!ZONES.includes(zone as (typeof ZONES)[number])) return null;
          const where = clip(row?.where, 220);
          const title = clip(row?.title, 48);
          const tool = clip(row?.tool, 80);
          if (!where || !title) return null;
          return {
            zone: zone as MakeupStep["zone"],
            title,
            where,
            how: clip(row?.how, 320) || where,
            tool: tool || "A thin layer",
          };
        })
        .filter((item): item is MakeupStep => item !== null)
        .slice(0, 8)
    : [];
  const rows = Array.isArray(data.looks) ? data.looks.map((item) => asRecord(item)) : [];
  const looks: MakeupLook[] = [];
  aims.forEach((id, index) => {
    const row = rows.find((item) => clip(item?.id, 16) === id) ?? rows[index] ?? null;
    const edit = clip(row?.edit, 700);
    if (!edit) return;
    looks.push({
      id,
      name: clip(row?.name, 24) || AIM_NAME[id],
      why: clip(row?.why, 180) || "Chosen for the face in the photo.",
      lesson: clip(row?.lesson, 520) || "Do the eyes with the eye open. Light shade through the lid you can see, darker warm brown on the outer third, blend upward, then liner and mascara.",
      edit,
    });
  });
  if (steps.length < 5 || looks.length < aims.length) {
    return { ok: false, message: "The reading was too thin to use. Try the photo again." };
  }
  const avoid = Array.isArray(data.avoid) ? data.avoid.map((item) => clip(item, 80)).filter(Boolean).slice(0, 3) : [];
  return {
    ok: true,
    reading: {
      eyeShape: clip(data.eyeShape, 32) || "unspecified",
      underEye: clip(data.underEye, 32) || "unspecified",
      skin: clip(data.skin, 180) || "Not described",
      brows: clip(data.brows, 180) || "Not described",
      lips: clip(data.lips, 180) || "Not described",
      summary: clip(data.summary, 420) || "Keep the makeup where the features need it, and leave the rest of the skin alone.",
      steps,
      looks,
      avoid,
    },
  };
}

function imageUrlFrom(json: unknown): string | null {
  const record = asRecord(json);
  const data = record?.data;
  if (Array.isArray(data)) {
    const first = asRecord(data[0]);
    if (typeof first?.url === "string" && first.url.startsWith("http")) return first.url;
    if (typeof first?.b64_json === "string" && first.b64_json.length > 32) {
      return `data:image/jpeg;base64,${first.b64_json}`;
    }
  }
  if (typeof record?.url === "string" && record.url.startsWith("http")) return record.url;
  return null;
}

async function inlineImage(url: string): Promise<string> {
  if (url.startsWith("data:")) return url;
  try {
    const response = await fetch(url, { signal: AbortSignal.timeout(20_000) });
    if (!response.ok) return url;
    const bytes = Buffer.from(await response.arrayBuffer());
    if (bytes.byteLength > 3_500_000) return url;
    const mime = (response.headers.get("content-type") || "image/jpeg").split(";")[0] || "image/jpeg";
    return `data:${mime};base64,${bytes.toString("base64")}`;
  } catch {
    return url;
  }
}

async function runRead(data: z.infer<typeof readInput>): Promise<MakeupReadResult> {
  const first = await postXai("/chat/completions", {
    model: "grok-4.5",
    temperature: 0.3,
    max_tokens: 3200,
    messages: [
      {
        role: "system",
        content:
          "You are a makeup artist reading one adult woman's face from a photo. You give precise placement, not a product catalog. You never change her age in the advice. If she says her eyes are hooded, eyeShape is hooded even if the crease looks open in the photo. If she says she has circles, underEye is circles. Do not invent a problem the photo and her answers do not show. Return JSON only.",
      },
      {
        role: "user",
        content: [
          { type: "image_url", image_url: { url: data.imageDataUrl } },
          { type: "text", text: readingPrompt(data) },
        ],
      },
    ],
  });
  if (!first.ok) return { ok: false, message: first.message };
  const text = messageText(first.json);
  if (!text) return { ok: false, message: "The reading came back empty. Try again." };
  return parseReading(text, data.aims);
}

async function runPaint(data: z.infer<typeof paintInput>): Promise<MakeupPaintResult> {
  const mature = data.age === "forties" || data.age === "fifties" || data.age === "sixty";
  const prompt = [
    "Photorealistic edit. VISIBLE MAKEUP. Someone looking at this photo must see eyeshadow, a darker outer corner, blush, lip color, and mascara. Do not return a bare face.",
    data.keepHair
      ? "The haircut and the hair color in this photo are already chosen. Do not change the length, the style, the parting, or the color of the hair. Do not add grey. Makeup on the face only."
      : "Do not restyle or recolor the hair.",
    "Do not turn her into a different or younger woman. Her features stay.",
    "Do not add people, text, logos, arrows, or watermarks.",
    `Makeup: ${data.edit}`,
    data.aim === "natural"
      ? "Natural means a light hand, but the blush, the lid color, and the lip tint must still be visible."
      : data.aim === "evening" || data.aim === "goingout"
        ? "This is a stronger evening face. The eyes and the lip should read immediately."
        : "This is a polished, finished face. The eyeshadow, blush, and lipstick must be easy to see. It is not a no-makeup look.",
    data.eyeShape.toLowerCase().includes("hood")
      ? "Her eyes are hooded. Put the darker shadow on the outer corner and just above the fold so it shows while her eyes are open."
      : "Put a darker warm brown on the outer corner of the eye and keep the inner corner lighter.",
    /circle|hollow|puff/i.test(data.underEye)
      ? "Brighten the darkness under the eyes with a warm concealer. Do not paint the under-eye white."
      : "",
    mature
      ? "Mature skin, in the manner of Jackie Alves: warm cream base, not a mask. No black ring of eyeliner. Brown depth at the outer corner. Pink or peach blush. Lip color with a little shine, not a dry brown matte."
      : "",
  ]
    .filter(Boolean)
    .join(" ");

  const edited = await postXai("/images/edits", {
    model: "grok-imagine-image-2.0",
    prompt,
    image: { type: "image_url", url: data.imageDataUrl },
    response_format: "url",
  });
  if (!edited.ok) return { ok: false, message: edited.message };
  const remote = imageUrlFrom(edited.json);
  if (!remote) return { ok: false, message: "The makeup was painted, but the image did not come back. Try again." };
  return { ok: true, imageUrl: await inlineImage(remote) };
}

type JobResult = MakeupReadResult | MakeupPaintResult;
type Job = { state: "pending" } | { state: "done"; result: JobResult; at: number };
const jobs = new Map<string, Job>();

function keepAlive(work: Promise<unknown>) {
  const safe = work.catch(() => undefined);
  const host = globalThis as { waitUntil?: (promise: Promise<unknown>) => void };
  if (typeof host.waitUntil === "function") host.waitUntil(safe);
}

function finish(id: string, result: JobResult) {
  jobs.set(id, { state: "done", result, at: Date.now() });
  const cutoff = Date.now() - 10 * 60_000;
  for (const [key, job] of jobs) {
    if (job.state === "done" && job.at < cutoff) jobs.delete(key);
  }
}

function enqueue(work: Promise<JobResult>) {
  const id = crypto.randomUUID();
  jobs.set(id, { state: "pending" });
  keepAlive(
    work.then(
      (result) => finish(id, result),
      () => finish(id, { ok: false, message: "The makeup reading could not finish. Try again." }),
    ),
  );
  return { jobId: id };
}

export type MakeupJobView = { pending: true } | { pending: false; result: JobResult };

export const readMakeup = createServerFn({ method: "POST" })
  .validator((input: unknown) => readInput.parse(input))
  .handler(async ({ data }) => enqueue(runRead(data)));

export const paintMakeup = createServerFn({ method: "POST" })
  .validator((input: unknown) => paintInput.parse(input))
  .handler(async ({ data }) => enqueue(runPaint(data)));

export const makeupJob = createServerFn({ method: "POST" })
  .validator((input: unknown) => z.object({ jobId: z.string().uuid() }).parse(input))
  .handler(async ({ data }): Promise<MakeupJobView> => {
    const job = jobs.get(data.jobId);
    if (!job) return { pending: false, result: { ok: false, message: "That makeup reading expired. Start it again." } };
    if (job.state === "pending") return { pending: true };
    return { pending: false, result: job.result };
  });
