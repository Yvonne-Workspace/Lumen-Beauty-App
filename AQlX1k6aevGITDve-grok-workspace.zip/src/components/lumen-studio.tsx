import { useState } from "react";
import { Camera } from "lucide-react";
import { CameraCapture } from "@/components/camera-capture";
import { HairFlow, PhotoGuide } from "@/components/hair-flow";
import { MakeupDesk } from "@/components/makeup-desk";
import { PhotoPick } from "@/components/photo-pick";
import type { HairProfile } from "@/lib/hair/engine";
import { fileToPortrait } from "@/lib/portrait";

const SAMPLE_SRC = "/portraits/sample.jpg";

export function LumenStudio() {
  const [section, setSection] = useState<"hair" | "makeup">("hair");
  const [cameraOpen, setCameraOpen] = useState(false);
  const [portrait, setPortrait] = useState<string | null>(null);
  const [age, setAge] = useState<HairProfile["age"] | null>(null);
  const [hair, setHair] = useState<{ name: string; color: string; image: string } | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  function applyPortrait(next: string) {
    setPortrait(next);
    setHair(null);
    setNotice(null);
  }

  async function useFile(file: File | undefined) {
    if (!file) return;
    setNotice(null);
    try {
      applyPortrait(await fileToPortrait(file));
    } catch (error) {
      setNotice(error instanceof Error ? error.message : "Could not use that photo.");
    }
  }

  async function useSample() {
    setNotice(null);
    try {
      const response = await fetch(SAMPLE_SRC);
      if (!response.ok) throw new Error("The sample portrait is missing.");
      const blob = await response.blob();
      applyPortrait(await fileToPortrait(new File([blob], "sample.jpg", { type: blob.type || "image/jpeg" })));
    } catch (error) {
      setNotice(error instanceof Error ? error.message : "Could not load the sample.");
    }
  }

  return (
    <main className="studio-shell">
      <header className="mb-4 flex items-end justify-between gap-4">
        <div>
          <p className="text-xs font-medium tracking-widest text-stone uppercase">Studio</p>
          <h1 className="wordmark mt-1 text-4xl text-ink md:text-5xl">Lumen</h1>
        </div>
        <p className="hidden max-w-xs text-right text-sm text-stone md:block">Hair colour and makeup for the same photo.</p>
      </header>

      <section className="mb-6 grid gap-3">
        {!portrait ? <PhotoGuide /> : null}
        <div className="panel p-4">
          <h2 className="text-sm font-medium text-ink">Your photo</h2>
          <p className="mt-1 text-sm text-stone">One photo is used for hair and makeup.</p>
          {portrait ? <img src={portrait} alt="The photo Lumen is using" className="mt-3 h-28 w-20 rounded-md object-cover" /> : null}
          <div className="mt-3 flex flex-wrap items-center gap-2">
            <PhotoPick
              onFile={(file) => void useFile(file)}
              takeLabel={portrait ? "Retake" : "Take a photo"}
              chooseLabel={portrait ? "Choose another" : "Choose a photo"}
            />
            <button type="button" className="btn btn-quiet min-h-14" onClick={() => setCameraOpen(true)}>
              <Camera className="size-4" aria-hidden="true" />
              Live camera
            </button>
            {!portrait ? (
              <button type="button" className="btn btn-quiet min-h-14" onClick={() => void useSample()}>
                Use the sample
              </button>
            ) : null}
          </div>
          <p className="mt-3 text-sm text-stone">
            Take a photo opens the phone camera. Choose a photo opens the gallery. If you are in WhatsApp and the camera does not open, use Choose a photo, or open this page in Chrome or Safari. Live camera often fails inside WhatsApp.
          </p>
        </div>
      </section>

      {notice ? <p className="note mb-4">{notice}</p> : null}

      <div className="mb-6 flex gap-2" role="tablist" aria-label="Studio">
        <button type="button" className={section === "hair" ? "btn btn-primary" : "btn btn-quiet"} aria-selected={section === "hair"} onClick={() => setSection("hair")}>
          Hair
        </button>
        <button type="button" className={section === "makeup" ? "btn btn-primary" : "btn btn-quiet"} aria-selected={section === "makeup"} onClick={() => setSection("makeup")}>
          Makeup
        </button>
      </div>

      {section === "hair" ? (
        <HairFlow
          portrait={portrait}
          onUse={(next, nextAge) => {
            setHair(next);
            setAge(nextAge);
            setSection("makeup");
          }}
        />
      ) : (
        <MakeupDesk portrait={portrait} onPortrait={applyPortrait} hair={hair} sharedAge={age} />
      )}

      {cameraOpen ? (
        <CameraCapture
          onClose={() => setCameraOpen(false)}
          onShot={(url) => {
            setCameraOpen(false);
            applyPortrait(url);
          }}
        />
      ) : null}
    </main>
  );
}
