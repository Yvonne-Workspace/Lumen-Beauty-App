import assert from "node:assert/strict";
import test from "node:test";
import { explainStudioError } from "./studio-error.ts";

test("a spending limit is not hidden as a generic studio failure", () => {
  const message = explainStudioError(403, {
    code: "personal-team-blocked:spending-limit",
    error: "You have run out of credits or need a Grok subscription.",
  });
  assert.match(message, /no credits left/i);
});
