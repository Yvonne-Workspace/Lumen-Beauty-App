import { useEffect, useRef, useState } from "react";
import { LoaderCircle } from "lucide-react";
import {
  makeupJob,
  paintMakeup,
  readMakeup,
  type MakeupLook,
  type MakeupReading,
  type MakeupStep,
} from "@/lib/makeup/studio.functions";
import { fitPortrait } from "@/lib/portrait";

const AGES = [
  { id: "under30", label: "Under 30" },
  { id: "thirties", label: "30s" },
  { id: "forties", label: "40s" },
  { id: "fifties", label: "50s" },
  { id: "sixty", label: "60+" },
] as const;

const AIMS = [
  { id: "natural", label: "Natural" },
  { id: "polished", label: "Polished" },
  { id: "work", label: "For work" },
  { id: "daytime", label: "Daytime" },
  { id: "evening", label: "Evening" },
  { id: "goingout", label: "Going out" },
] as const;

const CONCERNS = [
  { id: "hooded", label: "Hooded eyes" },
  { id: "circles", label: "Circles under the eyes" },
  { id: "lines", label: "Fine lines" },
  { id: "redness", label: "Redness" },
  { id: "brows", label: "Sparse brows" },
  { id: "lips", label: "Thin lips or lip lines" },
] as const;

type AgeId = (typeof AGES)[number]["id"];
type AimId = (typeof AIMS)[number]["id"];
type ConcernId = (typeof CONCERNS)[number]["id"];
type Zone = MakeupStep["zone"];

const ZONE_LABEL: Record<Zone, string> = {
  skin: "Skin",
  under: "Under-eye",
  cheek: "Cheek",
  brow: "Brow",
  lid: "Lid",
  crease: "Above the fold",
  liner: "Lash line",
  lip: "Lip",
};

export function MakeupDesk({
  portrait,
  hair,
  sharedAge = null,
}: {
  portrait: string | null;
  onPortrait: (value: string) => void;
  hair: { name: string; color: string; image: string } | null;
  sharedAge?: AgeId | null;
}) {
  const busyRef = useRef(false);
  const [ageId, setAgeId] = useState<AgeId | null>(sharedAge);
  const [aims, setAims] = useState<AimId[]>([]);
  const [concerns, setConcerns] = useState<ConcernId[]>([]);
  const [reading, setReading] = useState<MakeupReading | null>(null);
  const [stepIndex, setStepIndex] = useState(0);
  const [lookId, setLookId] = useState<string | null>(null);
  const [painted, setPainted] = useState<string | null>(null);
  const [split, setSplit] = useState(56);
  const [phase, setPhase] = useState<"idle" | "reading" | "painting">("idle");
  const [notice, setNotice] = useState<string | null>(null);

  const ready = Boolean(portrait && ageId && aims.length > 0);
  const look = reading?.looks.find((item) => item.id === lookId) ?? null;
  const step = reading?.steps[stepIndex] ?? null;
  const zone = step?.zone ?? "under";
  const hooded = reading?.eyeShape.toLowerCase().includes("hood") || concerns.includes("hooded");
  const base = hair?.image ?? portrait;

  useEffect(() => {
    if (sharedAge) setAgeId(sharedAge);
  }, [sharedAge]);

  useEffect(() => {
    setPainted(null);
  }, [hair?.image]);

  useEffect(() => {
    setReading(null);
    setPainted(null);
  }, [portrait]);

  function toggle(id: ConcernId) {
    setConcerns((current) => (current.includes(id) ? current.filter((item) => item !== id) : [...current, id]));
  }

  async function onRead() {
    if (!portrait || !ageId || aims.length === 0 || phase !== "idle" || busyRef.current) return;
    busyRef.current = true;
    setPhase("reading");
    setNotice(null);
    setPainted(null);
    try {
      const started = await readMakeup({ data: { imageDataUrl: portrait, age: ageId, aims, concerns } });
      const result = await waitForJob(started.jobId);
      if (!result.ok || !("reading" in result)) {
        setReading(null);
        setNotice("message" in result ? result.message : "The reading did not go through. Try again.");
        return;
      }
      setReading(result.reading);
      const first = result.reading.steps.findIndex((item) => item.zone === "under");
      setStepIndex(first >= 0 ? first : 0);
      const preferred = result.reading.looks.find((item) => item.id === aims[0]) ?? result.reading.looks[0];
      setLookId(preferred?.id ?? null);
    } catch {
      setNotice("The reading did not go through. Try again.");
    } finally {
      busyRef.current = false;
      setPhase("idle");
    }
  }

  async function onPaint(next: MakeupLook) {
    if (!portrait || !reading || !ageId || busyRef.current) return;
    setLookId(next.id);
    busyRef.current = true;
    setPhase("painting");
    setNotice(null);
    try {
      const started = await paintMakeup({
        data: {
          imageDataUrl: await fitPortrait(hair?.image ?? portrait),
          edit: next.edit,
          eyeShape: reading.eyeShape,
          underEye: reading.underEye,
          age: ageId,
          aim: next.id,
          keepHair: Boolean(hair),
        },
      });
      const result = await waitForJob(started.jobId);
      if (!result.ok || !("imageUrl" in result)) {
        setNotice("message" in result ? result.message : "The makeup did not paint. Try again.");
        return;
      }
      setPainted(result.imageUrl);
      setSplit(56);
    } catch {
      setNotice("The makeup did not paint. Try again.");
    } finally {
      busyRef.current = false;
      setPhase("idle");
    }
  }

  return (
    <div className="grid items-start gap-6 lg:grid-cols-[minmax(0,0.92fr)_minmax(0,1.08fr)] lg:gap-8">
      <section className="panel p-4">
        {base ? (
          <div className="relative">
            <Compare original={base} painted={painted} split={split} onSplit={setSplit} busy={phase !== "idle"} busyLabel={phase === "reading" ? "Reading your face…" : "Painting the makeup…"} />
            {hair ? (
              <p className="mt-2 text-sm text-stone">
                Wearing <span className="font-medium text-ink">{hair.name}</span> in {hair.color}. Makeup is painted on this hair. The hair colour and cut are left as chosen.
              </p>
            ) : (
              <p className="mt-2 text-sm text-stone">No cut chosen yet. Pick one in Hair and it will be on this face too.</p>
            )}
            <div className="mt-3">
              <button type="button" className="btn btn-primary" disabled={!ready || phase !== "idle"} onClick={() => void onRead()}>
                {phase === "reading" ? "Reading your face…" : "Read this face"}
              </button>
            </div>
          </div>
        ) : (
          <p className="text-sm text-stone">Add a photo above. The same photo is used for hair and makeup.</p>
        )}
        <div className="mt-4 grid gap-4">
          {sharedAge ? (
            <p className="text-sm text-stone">
              Age: <span className="font-medium text-ink">{AGES.find((item) => item.id === sharedAge)?.label}</span>. Taken from your hair answers.
            </p>
          ) : (
            <One label="Age range" options={AGES} selected={ageId} onPick={setAgeId} columns />
          )}
          <Many
            label="How should it feel?"
            hint="Pick every one you want to see. Each one is painted on the photo."
            options={AIMS}
            selected={aims}
            onPick={(id) => setAims((current) => (current.includes(id) ? current.filter((item) => item !== id) : [...current, id]))}
          />
          <Many
            label="What do you already know?"
            hint="Tick every one. The photo is still scanned for the rest."
            options={CONCERNS}
            selected={concerns}
            onPick={toggle}
          />
        </div>
        {portrait && !ready ? (
          <p className="mt-3 text-xs text-mist">{sharedAge ? "Pick a finish, then read the face." : "Add an age and the finish you want, then read the face."}</p>
        ) : null}
      </section>

      <section className="flex flex-col gap-5">
        <div>
          <h2 className="wordmark text-3xl text-ink">Where it goes</h2>
          <p className="mt-2 max-w-prose text-sm text-stone md:text-base">
            {reading
              ? reading.summary
              : "Lumen looks at the eyes, the under-eye, the skin, the brows, and the lips. Then it shows the makeup on your photo, and the exact place each product goes."}
          </p>
        </div>
        {notice ? <p className="note">{notice}</p> : null}
        {reading ? (
          <>
            <dl className="grid grid-cols-2 gap-2">
              {(
                [
                  ["Eyes", reading.eyeShape],
                  ["Under-eye", reading.underEye],
                  ["Skin", reading.skin],
                  ["Brows", reading.brows],
                  ["Lips", reading.lips],
                ] as const
              ).map(([label, value]) => (
                <div key={label} className="rounded-md border border-line bg-sheet px-3 py-2">
                  <dt className="text-xs text-mist">{label}</dt>
                  <dd className="mt-0.5 text-sm text-ink">{value}</dd>
                </div>
              ))}
            </dl>
            <FaceGuide hooded={hooded} zone={zone} onZone={(next) => {
              const index = reading.steps.findIndex((item) => item.zone === next);
              if (index >= 0) setStepIndex(index);
            }} />
            <div>
              <h3 className="text-sm font-medium text-ink">Show it on the photo</h3>
              <div className="mt-2 grid gap-2">
                {reading.looks.map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    className="choice"
                    aria-pressed={item.id === lookId}
                    disabled={phase !== "idle"}
                    onClick={() => void onPaint(item)}
                  >
                    <span className="text-sm font-medium text-ink">{item.name}</span>
                    <span className="mt-1 block text-sm text-stone">{item.why}</span>
                  </button>
                ))}
              </div>
              <p className="mt-2 text-xs text-mist">
                {look ? `${look.name} is on the photo. The how-to below is how to do it yourself.` : "Pick a finish. The how-to follows the one you pick."}
              </p>
            </div>
            {look ? (
              <div>
                <h3 className="text-sm font-medium text-ink">How to get {look.name}</h3>
                <p className="mt-2 text-sm text-stone">{look.lesson}</p>
                <ol className="mt-3 grid gap-2">
                  {reading.steps.map((item, index) => {
                    const eye = item.zone === "lid" || item.zone === "crease" || item.zone === "liner";
                    const label = item.zone === "crease" ? (hooded ? "Above the fold" : "Crease") : ZONE_LABEL[item.zone];
                    return (
                      <li key={`${item.zone}-${index}`}>
                        <button
                          type="button"
                          className="choice"
                          aria-pressed={index === stepIndex}
                          onClick={() => setStepIndex(index)}
                        >
                          <span className="text-xs text-mist">
                            {index + 1}. {eye ? "Eyes · " : ""}
                            {label}
                          </span>
                          <span className="mt-0.5 block text-sm font-medium text-ink">{item.title}</span>
                          <span className="mt-1 block text-sm text-stone">{item.how}</span>
                          <span className="mt-1 block text-sm text-ink">{item.tool}</span>
                        </button>
                      </li>
                    );
                  })}
                </ol>
              </div>
            ) : null}
            {reading.avoid.length > 0 ? (
              <p className="text-sm text-stone">
                <span className="font-medium text-ink">Leave alone: </span>
                {reading.avoid.join(" · ")}
              </p>
            ) : null}
            {ageId === "forties" || ageId === "fifties" || ageId === "sixty" ? (
              <p className="text-sm text-stone">
                For a mature face, the placement follows{" "}
                <a className="font-medium text-ink underline decoration-line underline-offset-4" href="https://www.youtube.com/@jackiealves" target="_blank" rel="noreferrer">
                  Jackie Alves
                </a>
                . Warm cream base, powder only where the skin shines, depth at the outer corner, brown liner instead of a black ring, and a lip with a little shine.
              </p>
            ) : null}
          </>
        ) : (
          <ol className="grid gap-3 text-sm text-stone">
            <li className="panel px-4 py-3">
              <span className="font-medium text-ink">1. The eyes. </span>
              Hooded lids, a hidden crease, circles, and lines change where the color is allowed to go.
            </li>
            <li className="panel px-4 py-3">
              <span className="font-medium text-ink">2. The map. </span>
              Each step lights up the place on the face. Mature skin stays natural. A younger face can be fresher, still not a mask.
            </li>
            <li className="panel px-4 py-3">
              <span className="font-medium text-ink">3. The how-to. </span>
              The finish you pick comes with the eye lesson and every step, in the order you do them.
            </li>
          </ol>
        )}
      </section>
    </div>
  );
}

function FaceGuide({ hooded, zone, onZone }: { hooded: boolean; zone: Zone; onZone: (zone: Zone) => void }) {
  return (
    <div className="panel p-4">
      <p className="text-sm font-medium text-ink">Where to put it</p>
      <p className="mt-1 text-xs text-mist">
        {hooded
          ? "The lid folds over. Color that has to show goes above the fold, not inside it."
          : "Tap a place. The step beside it says what goes there."}
      </p>
      <div className="mt-3 grid gap-3 sm:grid-cols-2">
        <EyeMap hooded={hooded} zone={zone} onZone={onZone} />
        <FaceMap zone={zone} onZone={onZone} />
      </div>
    </div>
  );
}

function EyeMap({ hooded, zone, onZone }: { hooded: boolean; zone: Zone; onZone: (zone: Zone) => void }) {
  const on = (id: Zone) => (zone === id ? "#2c3338" : "#e7e1d8");
  const ink = (id: Zone) => (zone === id ? "#f7f5f2" : "#1a1816");
  return (
    <svg viewBox="0 0 220 140" className="w-full" role="img" aria-label={hooded ? "Hooded eye placement" : "Eye placement"}>
      <rect width="220" height="140" rx="12" fill="#fbfaf7" />
      <text x="16" y="22" fill="#6e6862" fontSize="11" fontFamily="Outfit, sans-serif">
        {hooded ? "Hooded eye, open" : "Eye, open"}
      </text>
      <path d="M28 78 C70 48 150 48 192 78 C150 96 70 96 28 78 Z" fill="#fff" stroke="#1a1816" strokeWidth="1.4" />
      {hooded ? (
        <path d="M46 74 C80 66 140 66 176 76" fill="none" stroke="#1a1816" strokeWidth="1.2" />
      ) : (
        <path d="M48 62 C80 46 146 46 178 64" fill="none" stroke="#1a1816" strokeWidth="1.2" />
      )}
      <path d="M40 80 C78 92 146 92 184 80" fill="none" stroke="#1a1816" strokeWidth="1.6" />
      <circle cx="112" cy="80" r="8" fill="#1a1816" />
      <Spot x={78} y={hooded ? 58 : 50} label="Lid" active={zone === "lid"} fill={on("lid")} ink={ink("lid")} onClick={() => onZone("lid")} />
      <Spot x={150} y={hooded ? 52 : 40} label="Above" active={zone === "crease"} fill={on("crease")} ink={ink("crease")} onClick={() => onZone("crease")} />
      <Spot x={168} y={86} label="Line" active={zone === "liner"} fill={on("liner")} ink={ink("liner")} onClick={() => onZone("liner")} />
    </svg>
  );
}

function FaceMap({ zone, onZone }: { zone: Zone; onZone: (zone: Zone) => void }) {
  const on = (id: Zone) => (zone === id ? "#2c3338" : "#e7e1d8");
  const ink = (id: Zone) => (zone === id ? "#f7f5f2" : "#1a1816");
  return (
    <svg viewBox="0 0 220 200" className="w-full" role="img" aria-label="Face placement">
      <rect width="220" height="200" rx="12" fill="#fbfaf7" />
      <ellipse cx="110" cy="96" rx="58" ry="74" fill="#fff" stroke="#1a1816" strokeWidth="1.4" />
      <path d="M78 78 C90 70 102 70 112 78" fill="none" stroke="#1a1816" />
      <path d="M108 78 C118 70 130 70 142 78" fill="none" stroke="#1a1816" />
      <path d="M110 88 V112" stroke="#1a1816" strokeWidth="1.1" />
      <path d="M92 132 C104 140 116 140 128 132" fill="none" stroke="#1a1816" strokeWidth="1.3" />
      <Spot x={110} y={48} label="Skin" active={zone === "skin"} fill={on("skin")} ink={ink("skin")} onClick={() => onZone("skin")} />
      <Spot x={70} y={86} label="Under" active={zone === "under"} fill={on("under")} ink={ink("under")} onClick={() => onZone("under")} />
      <Spot x={156} y={118} label="Cheek" active={zone === "cheek"} fill={on("cheek")} ink={ink("cheek")} onClick={() => onZone("cheek")} />
      <Spot x={58} y={64} label="Brow" active={zone === "brow"} fill={on("brow")} ink={ink("brow")} onClick={() => onZone("brow")} />
      <Spot x={110} y={154} label="Lip" active={zone === "lip"} fill={on("lip")} ink={ink("lip")} onClick={() => onZone("lip")} />
    </svg>
  );
}

function Spot({
  x,
  y,
  label,
  fill,
  ink,
  active,
  onClick,
}: {
  x: number;
  y: number;
  label: string;
  fill: string;
  ink: string;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <g onClick={onClick} className="cursor-pointer" role="button" tabIndex={0} aria-pressed={active} onKeyDown={(event) => {
      if (event.key === "Enter" || event.key === " ") onClick();
    }}>
      <rect x={x - 26} y={y - 11} width="52" height="22" rx="11" fill={fill} stroke="#1a1816" strokeWidth="1" />
      <text x={x} y={y + 4} textAnchor="middle" fill={ink} fontSize="10" fontFamily="Outfit, sans-serif">
        {label}
      </text>
    </g>
  );
}

function One<T extends string>({
  label,
  options,
  selected,
  onPick,
  columns,
}: {
  label: string;
  options: readonly { id: T; label: string }[];
  selected: T | null;
  onPick: (id: T) => void;
  columns?: boolean;
}) {
  return (
    <div>
      <p className="text-sm font-medium text-ink">{label}</p>
      <div className={columns ? "mt-2 grid grid-cols-2 gap-2" : "mt-2 grid gap-2"}>
        {options.map((item) => (
          <button key={item.id} type="button" className="choice" aria-pressed={selected === item.id} onClick={() => onPick(item.id)}>
            {item.label}
          </button>
        ))}
      </div>
    </div>
  );
}

function Many<T extends string>({
  label,
  hint,
  options,
  selected,
  onPick,
}: {
  label: string;
  hint: string;
  options: readonly { id: T; label: string }[];
  selected: T[];
  onPick: (id: T) => void;
}) {
  return (
    <div>
      <p className="text-sm font-medium text-ink">{label}</p>
      <p className="mt-1 text-xs text-mist">{hint}</p>
      <div className="mt-2 grid grid-cols-2 gap-2">
        {options.map((item) => (
          <button key={item.id} type="button" className="choice" aria-pressed={selected.includes(item.id)} onClick={() => onPick(item.id)}>
            {item.label}
          </button>
        ))}
      </div>
    </div>
  );
}

function Compare({
  original,
  painted,
  split,
  onSplit,
  busy,
  busyLabel,
}: {
  original: string;
  painted: string | null;
  split: number;
  onSplit: (value: number) => void;
  busy: boolean;
  busyLabel: string;
}) {
  return (
    <div className="frame">
      <img src={painted ?? original} alt={painted ? "Portrait with the makeup" : "Uploaded portrait"} className="block aspect-[3/4] w-full object-cover" />
      {painted ? (
        <img src={original} alt="" className="pointer-events-none absolute inset-0 h-full w-full object-cover" style={{ clipPath: `inset(0 ${100 - split}% 0 0)` }} />
      ) : null}
      {painted ? (
        <>
          <div className="pointer-events-none absolute inset-y-0 w-px bg-sheet" style={{ left: `${split}%` }} />
          <input className="compare-range" type="range" min={2} max={98} value={split} aria-label="Compare the bare face and the makeup" onChange={(event) => onSplit(Number(event.target.value))} />
          <div className="pointer-events-none absolute inset-x-0 bottom-0 flex justify-between px-3 py-2 text-xs font-medium text-char-fg">
            <span className="rounded-full bg-char/80 px-2 py-1">Before</span>
            <span className="rounded-full bg-char/80 px-2 py-1">Makeup</span>
          </div>
        </>
      ) : null}
      {busy ? (
        <div className="absolute inset-0 grid place-items-center bg-ink/35 text-sm font-medium text-char-fg">
          <span className="inline-flex items-center gap-2 rounded-full bg-char px-3 py-2">
            <LoaderCircle className="size-4 animate-spin" aria-hidden="true" />
            {busyLabel}
          </span>
        </div>
      ) : null}
    </div>
  );
}

async function waitForJob(jobId: string) {
  for (let attempt = 0; attempt < 45; attempt += 1) {
    const step = await makeupJob({ data: { jobId } });
    if (!step.pending) return step.result;
    await new Promise((resolve) => setTimeout(resolve, 2000));
  }
  return { ok: false as const, message: "That is still running. Stay on this page and try once more." };
}
