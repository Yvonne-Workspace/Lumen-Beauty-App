//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-D0qJHS1Z.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-DHqdvosm.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DHqdvosm.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-uJnD42Im.js"]
	}
} });
//#endregion
export { tsrStartManifest };
